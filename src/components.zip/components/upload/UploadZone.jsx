import React from "react";
import { UploadCloud } from "lucide-react";

export default function UploadZone() {

  return (
    <div className="upload-zone-v15">

      <UploadCloud size={42} />

      <h3>????? ???? ?????</h3>

      <p>
        PDF? DWG? XLSX ?? ?????? ???? ?????
      </p>

    </div>
  );
}
