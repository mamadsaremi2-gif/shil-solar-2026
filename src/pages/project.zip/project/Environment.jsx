import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import ShilPageShell from "../../components/ShilPageShell";
import ProjectMiniRail from "../../components/ProjectMiniRail.jsx";
import SmartCityInput, { findIranCityByName, getDefaultIranCity } from "../../components/SmartCityInput";
import { analyzeEnvironmentForEngineering, estimateRecommendedTilt, normalizePersianNumber } from "../../core/environment/environmentAssessment.js";
import { approveProjectStep } from "../../workflow/projectWorkflow.js";
import { clearScenarioFlow, isScenarioFlowFor } from "../../workflow/flowIsolation.js";

const directionOptions = [
  { key: "north", label: "Ø´Ù…Ø§Ù„", deg: 0 },
  { key: "east", label: "Ø´Ø±Ù‚", deg: 90 },
  { key: "south", label: "Ø¬Ù†ÙˆØ¨", deg: 180 },
  { key: "west", label: "ØºØ±Ø¨", deg: 270 },
];
const defaultDirectionSlots = { north: "north", east: "east", south: "south", west: "west" };
function toNumberInput(value, fallback = 0) { const n = Number(normalizePersianNumber(value)); return Number.isFinite(n) ? n : fallback; }
function normalizeDeg(value) { const n = toNumberInput(value, 180); return ((n % 360) + 360) % 360; }

const installTypes = [
  { key: "urban", label: "Ø´Ù‡Ø±ÛŒ", humidityOffset: 0, soiling: 3, description: "Ù…Ø­ÛŒØ· Ù…Ø¹Ù…ÙˆÙ„ Ø´Ù‡Ø±ÛŒ Ø¨Ø§ Ø±ÛŒØ³Ú© Ù…ØªÙˆØ³Ø· Ú¯Ø±Ø¯ÙˆØºØ¨Ø§Ø±" },
  { key: "industrial", label: "ØµÙ†Ø¹ØªÛŒ", humidityOffset: 0, soiling: 7, description: "Ú¯Ø±Ø¯ÙˆØºØ¨Ø§Ø±ØŒ Ø¯ÙˆØ¯Ù‡ Ùˆ Ø¢Ù„ÙˆØ¯Ú¯ÛŒ ØµÙ†Ø¹ØªÛŒ Ø¨ÛŒØ´ØªØ±" },
  { key: "coastal", label: "Ø³Ø§Ø­Ù„ÛŒ", humidityOffset: 18, soiling: 5, description: "Ø±Ø·ÙˆØ¨Øª Ùˆ Ø®ÙˆØ±Ø¯Ú¯ÛŒ Ø¨Ø§Ù„Ø§Ø› Ù†ÛŒØ§Ø²Ù…Ù†Ø¯ IP Ùˆ Ù¾ÙˆØ´Ø´ Ø¨Ù‡ØªØ±" },
  { key: "mountain", label: "Ú©ÙˆÙ‡Ø³ØªØ§Ù†ÛŒ", humidityOffset: -8, soiling: 2, description: "Ù‡ÙˆØ§ÛŒ Ø®Ø´Ú©â€ŒØªØ±ØŒ Ø¯Ù…Ø§ÛŒ Ù¾Ø§ÛŒÛŒÙ†â€ŒØªØ± Ùˆ Ú©Ù†ØªØ±Ù„ ÙˆÙ„ØªØ§Ú˜ Ø³Ø±Ù…Ø§ÛŒÛŒ" },
  { key: "desert", label: "Ú©ÙˆÛŒØ±ÛŒ", humidityOffset: -14, soiling: 8, description: "ØªØ§Ø¨Ø´ Ø¨Ø§Ù„Ø§ØŒ Ú¯Ø±Ø¯ÙˆØºØ¨Ø§Ø± Ø²ÛŒØ§Ø¯ Ùˆ Ù†ÛŒØ§Ø² Ø¨Ù‡ Ø¨Ø±Ù†Ø§Ù…Ù‡ Ø´Ø³Øªâ€ŒÙˆØ´Ùˆ" },
];

const isfahan = getDefaultIranCity();
const defaultClimate = {
  temperature: Number(isfahan?.averageTemperature ?? 23),
  temperatureMinC: Number(isfahan?.minTemperature ?? -4),
  temperatureMaxC: Number(isfahan?.maxTemperature ?? 41),
  altitude: Number(isfahan?.altitude ?? 1574),
  humidity: Number(isfahan?.humidity ?? 28),
  peakSunHours: Number(isfahan?.sunHours ?? 5.7),
  latitude: isfahan?.latitude ?? 32.6546,
  longitude: isfahan?.longitude ?? 51.668,
};

function clamp(value, min, max) {
  const number = Number(value);
  if (Number.isNaN(number)) return min;
  return Math.max(min, Math.min(max, number));
}

function getHumidityByInstallType(baseHumidity, installTypeKey) {
  const installType = installTypes.find((item) => item.key === installTypeKey);
  const next = Number(baseHumidity || defaultClimate.humidity) + Number(installType?.humidityOffset || 0);
  return Math.max(5, Math.min(95, Math.round(next)));
}

function cityToClimate(city, domain, installType) {
  const base = city ? {
    temperature: Number(city.averageTemperature ?? defaultClimate.temperature),
    temperatureMinC: Number(city.minTemperature ?? defaultClimate.temperatureMinC),
    temperatureMaxC: Number(city.maxTemperature ?? defaultClimate.temperatureMaxC),
    altitude: Number(city.altitude ?? defaultClimate.altitude),
    humidity: Number(city.humidity ?? defaultClimate.humidity),
    peakSunHours: domain === "solar" ? Number(city.sunHours ?? defaultClimate.peakSunHours) : 0,
    latitude: city.latitude ?? defaultClimate.latitude,
    longitude: city.longitude ?? defaultClimate.longitude,
  } : {
    ...defaultClimate,
    peakSunHours: domain === "solar" ? defaultClimate.peakSunHours : 0,
  };

  return {
    ...base,
    humidity: getHumidityByInstallType(base.humidity, installType),
  };
}

function fileToAttachment(file, type, latitude, longitude) {
  if (!file) return null;
  return {
    type,
    name: file.name,
    size: file.size,
    mime: file.type,
    capturedAt: new Date().toISOString(),
    capturedLocation: {
      latitude: latitude === "" ? null : Number(latitude),
      longitude: longitude === "" ? null : Number(longitude),
    },
    usage: type === "compass-screenshot" ? "orientation-reference" : "site-condition-reference",
  };
}

export default function Environment() {
  const navigate = useNavigate();
  const { domain = localStorage.getItem("shil:scenarioDomain") || "solar" } = useParams();

  const [city, setCity] = useState(isfahan?.name || "Ø§ØµÙÙ‡Ø§Ù†");
  const [selectedCity, setSelectedCity] = useState(isfahan || null);
  const [manualOverride, setManualOverride] = useState(false);
  const [address, setAddress] = useState("");
  const [gpsMode, setGpsMode] = useState("auto");
  const [latitude, setLatitude] = useState(String(defaultClimate.latitude));
  const [longitude, setLongitude] = useState(String(defaultClimate.longitude));
  const [installType, setInstallType] = useState("urban");
  const [manualClimate, setManualClimate] = useState(() => cityToClimate(isfahan, domain, "urban"));
  const [compassAttachment, setCompassAttachment] = useState(null);
  const [siteAttachments, setSiteAttachments] = useState([]);
  const [compassPreview, setCompassPreview] = useState("");
  const [sitePreviews, setSitePreviews] = useState([]);
  const [savedSiteImageCount, setSavedSiteImageCount] = useState(() => Number(localStorage.getItem("shil:environmentSiteImageCount") || 0));
  const [savedCompassImage, setSavedCompassImage] = useState(() => localStorage.getItem("shil:environmentCompassSaved") === "true");
  const [compassUploadChoice, setCompassUploadChoice] = useState("ask");
  const [gpsStatus, setGpsStatus] = useState("");
  const [validationMessage, setValidationMessage] = useState("");
  const [installTiltDeg, setInstallTiltDeg] = useState(String(estimateRecommendedTilt(defaultClimate.latitude)));
  const [installAzimuthDeg, setInstallAzimuthDeg] = useState("180");
  const [directionSlots, setDirectionSlots] = useState(defaultDirectionSlots);

  const activeInstallType = installTypes.find((item) => item.key === installType) || installTypes[0];

  useEffect(() => {
    const resolved = findIranCityByName(city) || selectedCity;
    if (!resolved || manualOverride) return;
    const nextClimate = cityToClimate(resolved, domain, installType);
    setManualClimate(nextClimate);
    if (gpsMode === "auto") {
      setLatitude(String(nextClimate.latitude ?? ""));
      setLongitude(String(nextClimate.longitude ?? ""));
      setInstallTiltDeg(String(estimateRecommendedTilt(nextClimate.latitude)));
    }
  }, [city, selectedCity, domain, installType, gpsMode, manualOverride]);

  const climate = useMemo(() => ({
    temperature: Number(manualClimate.temperature),
    temperatureMinC: Number(manualClimate.temperatureMinC),
    temperatureMaxC: Number(manualClimate.temperatureMaxC),
    altitude: Number(manualClimate.altitude),
    humidity: clamp(manualClimate.humidity, 5, 95),
    peakSunHours: domain === "solar" ? Number(manualClimate.peakSunHours) : 0,
    latitude,
    longitude,
  }), [manualClimate, domain, latitude, longitude]);

  const assessment = useMemo(() => analyzeEnvironmentForEngineering({
    domain,
    city,
    province: selectedCity?.province || "Ø§ØµÙÙ‡Ø§Ù†",
    address,
    gpsMode,
    latitude: latitude === "" ? null : Number(latitude),
    longitude: longitude === "" ? null : Number(longitude),
    installType: activeInstallType.key,
    installTypeLabel: activeInstallType.label,
    temperatureAverageC: climate.temperature,
    temperatureMaxC: climate.temperatureMaxC,
    temperatureMinC: climate.temperatureMinC,
    altitude: climate.altitude,
    humidity: climate.humidity,
    peakSunHours: climate.peakSunHours,
    soilingLossPercent: activeInstallType.soiling,
    wiringLossPercent: 3,
    selectedTiltDeg: toNumberInput(installTiltDeg, estimateRecommendedTilt(latitude)),
    selectedAzimuthDeg: normalizeDeg(installAzimuthDeg),
    directionSlots,
    compassAttachment,
    siteAttachments,
    siteAttachment: siteAttachments[0] || null,
  }), [domain, city, selectedCity, address, gpsMode, latitude, longitude, activeInstallType, climate, installTiltDeg, installAzimuthDeg, directionSlots, compassAttachment, siteAttachments]);

  const pickCity = (item) => {
    if (!item) return;
    setManualOverride(false);
    setSelectedCity(item);
    setCity(item.name || "");
    const nextClimate = cityToClimate(item, domain, installType);
    setManualClimate(nextClimate);
    setLatitude(item.latitude ? String(item.latitude) : "");
    setLongitude(item.longitude ? String(item.longitude) : "");
  };

  const updateClimate = (key, value) => {
    setManualOverride(true);
    setManualClimate((prev) => ({ ...prev, [key]: value }));
  };

  const restoreCityClimate = () => {
    const resolved = findIranCityByName(city) || selectedCity || isfahan;
    setManualOverride(false);
    setSelectedCity(resolved);
    setCity(resolved.name);
    const nextClimate = cityToClimate(resolved, domain, installType);
    setManualClimate(nextClimate);
    setLatitude(String(nextClimate.latitude ?? ""));
    setLongitude(String(nextClimate.longitude ?? ""));
    setInstallTiltDeg(String(estimateRecommendedTilt(nextClimate.latitude)));
    setInstallAzimuthDeg("180");
  };

  const readPreview = (file, setter) => {
    if (!file) {
      setter("");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setter(String(reader.result || ""));
    reader.readAsDataURL(file);
  };

  const handleCompassUpload = (event) => {
    const file = event.target.files?.[0];
    setCompassAttachment(fileToAttachment(file, "compass-screenshot", latitude, longitude));
    readPreview(file, setCompassPreview);
  };

  const handleSiteUpload = (event) => {
    const files = Array.from(event.target.files || []);
    setSiteAttachments(files.map((file) => fileToAttachment(file, "site-photo", latitude, longitude)).filter(Boolean));

    if (!files.length) {
      setSitePreviews([]);
      return;
    }

    Promise.all(files.map((file) => new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = () => resolve(String(reader.result || ""));
      reader.readAsDataURL(file);
    }))).then(setSitePreviews);
  };

  const saveInstallationImages = () => {
    try {
      localStorage.setItem("shil:environmentSiteImages", JSON.stringify(sitePreviews));
      localStorage.setItem("shil:environmentSiteImageCount", String(sitePreviews.length));
      localStorage.setItem("shil:environmentCompassPreview", compassPreview || "");
      localStorage.setItem("shil:environmentCompassSaved", compassPreview ? "true" : "false");
      setSavedSiteImageCount(sitePreviews.length);
      setSavedCompassImage(Boolean(compassPreview));
    } catch {
      setValidationMessage("Ø­Ø¬Ù… ØªØµØ§ÙˆÛŒØ± Ø¨Ø±Ø§ÛŒ Ø°Ø®ÛŒØ±Ù‡ Ù…Ø­Ù„ÛŒ Ø²ÛŒØ§Ø¯ Ø§Ø³ØªØ› Ù„Ø·ÙØ§Ù‹ ØªØ¹Ø¯Ø§Ø¯ ÛŒØ§ Ø­Ø¬Ù… Ø¹Ú©Ø³â€ŒÙ‡Ø§ Ø±Ø§ Ú©Ù…ØªØ± Ú©Ù†.");
    }
  };

  const routeStatusLabel = useMemo(() => {
    if (gpsMode === "manual") return gpsStatus ? "Ù…Ø³ÛŒØ± Ø¨Ø§ Ù„ÙˆÚ©ÛŒØ´Ù† Ø¯Ø³ØªÚ¯Ø§Ù‡ Ø«Ø¨Øª Ø´Ø¯Ù‡ Ø§Ø³Øª" : "Ù…Ø³ÛŒØ± Ø¨Ø§ Ù…Ø®ØªØµØ§Øª Ø¯Ø³ØªÛŒ Ù¾ÛŒØ´ Ø±ÙØªÙ‡ Ø§Ø³Øª";
    if (manualOverride) return "Ù…Ø³ÛŒØ± Ø¨Ø§ Ø¯Ø§Ø¯Ù‡â€ŒÙ‡Ø§ÛŒ Ø¯Ø³ØªÛŒ Ø§Ù‚Ù„ÛŒÙ…ÛŒ Ù¾ÛŒØ´ Ø±ÙØªÙ‡ Ø§Ø³Øª";
    if (selectedCity) return `Ù…Ø³ÛŒØ± Ø¨Ø§ Ø´Ù‡Ø± ${selectedCity.name} Ù¾ÛŒØ´ Ø±ÙØªÙ‡ Ø§Ø³Øª`;
    return "Ù…Ø³ÛŒØ± Ø¨Ø§ ÙˆØ±ÙˆØ¯ Ø¯Ø³ØªÛŒ Ø´Ù‡Ø± Ù¾ÛŒØ´ Ø±ÙØªÙ‡ Ø§Ø³Øª";
  }, [gpsMode, gpsStatus, manualOverride, selectedCity]);

  const requestCurrentLocation = () => {
    if (!navigator.geolocation) {
      setGpsStatus("Ù…Ø±ÙˆØ±Ú¯Ø± Ø§ÛŒÙ† Ø¯Ø³ØªÚ¯Ø§Ù‡ GPS Ø±Ø§ Ù¾Ø´ØªÛŒØ¨Ø§Ù†ÛŒ Ù†Ù…ÛŒâ€ŒÚ©Ù†Ø¯.");
      return;
    }

    setGpsStatus("Ø¯Ø± Ø­Ø§Ù„ Ø¯Ø±ÛŒØ§ÙØª Ù…ÙˆÙ‚Ø¹ÛŒØª Ø¯Ø³ØªÚ¯Ø§Ù‡...");
    navigator.geolocation.getCurrentPosition(
      (position) => {
        setGpsMode("manual");
        setLatitude(String(position.coords.latitude));
        setLongitude(String(position.coords.longitude));
        setGpsStatus(`Ù…ÙˆÙ‚Ø¹ÛŒØª Ø¯Ø³ØªÚ¯Ø§Ù‡ Ø«Ø¨Øª Ø´Ø¯. Ø¯Ù‚Øª ØªÙ‚Ø±ÛŒØ¨ÛŒ: ${Math.round(position.coords.accuracy || 0)} Ù…ØªØ±`);
      },
      () => setGpsStatus("Ø¯Ø³ØªØ±Ø³ÛŒ Ø¨Ù‡ Ù…ÙˆÙ‚Ø¹ÛŒØª Ø¯Ø§Ø¯Ù‡ Ù†Ø´Ø¯ ÛŒØ§ Ø¯Ø±ÛŒØ§ÙØª GPS Ù†Ø§Ù…ÙˆÙÙ‚ Ø¨ÙˆØ¯."),
      { enableHighAccuracy: true, timeout: 9000, maximumAge: 60000 }
    );
  };

  const confirmEnvironment = () => {
    const lat = latitude === "" ? null : Number(latitude);
    const lng = longitude === "" ? null : Number(longitude);

    if (!city.trim()) {
      setValidationMessage("Ù†Ø§Ù… Ø´Ù‡Ø± Ù¾Ø±ÙˆÚ˜Ù‡ Ø¨Ø§ÛŒØ¯ ÙˆØ§Ø±Ø¯ ÛŒØ§ Ø§Ø² Ù¾ÛŒØ´Ù†Ù‡Ø§Ø¯Ù‡Ø§ Ø§Ù†ØªØ®Ø§Ø¨ Ø´ÙˆØ¯.");
      return;
    }
    if (lat !== null && (lat < 24 || lat > 40)) {
      setValidationMessage("Ø¹Ø±Ø¶ Ø¬ØºØ±Ø§ÙÛŒØ§ÛŒÛŒ ÙˆØ§Ø±Ø¯Ø´Ø¯Ù‡ Ø®Ø§Ø±Ø¬ Ø§Ø² Ø¨Ø§Ø²Ù‡ Ù…Ø¹Ù…ÙˆÙ„ Ø§ÛŒØ±Ø§Ù† Ø§Ø³Øª.");
      return;
    }
    if (lng !== null && (lng < 43 || lng > 64)) {
      setValidationMessage("Ø·ÙˆÙ„ Ø¬ØºØ±Ø§ÙÛŒØ§ÛŒÛŒ ÙˆØ§Ø±Ø¯Ø´Ø¯Ù‡ Ø®Ø§Ø±Ø¬ Ø§Ø² Ø¨Ø§Ø²Ù‡ Ù…Ø¹Ù…ÙˆÙ„ Ø§ÛŒØ±Ø§Ù† Ø§Ø³Øª.");
      return;
    }

    const environmentDraft = {
      domain,
      province: selectedCity?.province || "Ø§ØµÙÙ‡Ø§Ù†",
      city,
      address,
      gpsMode,
      latitude: lat,
      longitude: lng,
      installType: activeInstallType.key,
      installTypeLabel: activeInstallType.label,
      temperatureAverageC: climate.temperature,
      temperatureMaxC: climate.temperatureMaxC,
      temperatureMinC: climate.temperatureMinC,
      altitude: climate.altitude,
      humidity: climate.humidity,
      peakSunHours: climate.peakSunHours,
      soilingLossPercent: activeInstallType.soiling,
      recommendedTiltDeg: assessment.recommendedTiltDeg,
      recommendedAzimuthDeg: assessment.recommendedAzimuthDeg,
      selectedTiltDeg: assessment.selectedTiltDeg,
      selectedAzimuthDeg: assessment.selectedAzimuthDeg,
      directionSlots,
      orientationLossPercent: assessment.orientationLossPercent,
      tiltLossPercent: assessment.tiltLossPercent,
      totalOrientationLossPercent: assessment.totalOrientationLossPercent,
      orientationEfficiency: assessment.orientationEfficiency,
      totalLossPercent: assessment.totalLossPercent,
      effectiveEfficiency: assessment.effectiveEfficiency,
      thermalDeratePercent: assessment.thermalDeratePercent,
      recommendedIngressProtection: assessment.recommendedIngressProtection,
      corrosionRisk: assessment.corrosionRisk,
      needsAntiCorrosion: assessment.needsAntiCorrosion,
      compassAttachment,
      siteAttachments,
      siteAttachment: siteAttachments[0] || null,
      savedSiteImageCount,
      savedCompassImage,
      routeStatusLabel,
      engineeringAssessment: assessment,
      manualOverride,
      source: selectedCity ? "iran-city-smart-catalog-with-manual-override" : "manual-entry",
    };

    localStorage.setItem("shil:environmentDraft", JSON.stringify(environmentDraft));
    approveProjectStep("environment");
    localStorage.setItem("shil:environmentAssessment", JSON.stringify(assessment));

    const urlParams = new URLSearchParams(window.location.search || "");
    const scenarioFlowActive = urlParams.get("from") === "scenario" && isScenarioFlowFor(domain);
    const selectedScenario = (() => {
      try { return JSON.parse(localStorage.getItem("shil:selectedScenario") || "null"); }
      catch { return null; }
    })();

    if (scenarioFlowActive && ["solar", "emergency"].includes(domain) && selectedScenario?.id) {
      const scenarioDomain = selectedScenario.domain || domain;
      localStorage.setItem("shil:calculationMethod", "equipment");
      localStorage.setItem("shil:scenarioNextStep", `${scenarioDomain}-equipment-list`);
      localStorage.setItem("shil:scenarioEquipmentBranch", scenarioDomain);
      navigate("/new-project/method");
      return;
    }

    if (urlParams.get("from") !== "scenario") {
      clearScenarioFlow();
    }
    navigate("/new-project/method");
  };

  return (
    <ShilPageShell
      title="Ø´Ø±Ø§ÛŒØ· Ù…Ø­ÛŒØ·ÛŒ"
      backLabel="Ø¨Ø§Ø²Ú¯Ø´Øª"
      nextLabel="ØªØ§ÛŒÛŒØ¯ Ù…Ø±Ø­Ù„Ù‡"
      prevLabel="Ù…Ø±Ø­Ù„Ù‡ Ù‚Ø¨Ù„"
      draftLabel="Ø°Ø®ÛŒØ±Ù‡"
      scrollXVisible
    >
      <ProjectMiniRail />
      <div className="shil-env-page">
        <section className="shil-env-card">
          <h3 className="shil-section-title">Ù…ÙˆÙ‚Ø¹ÛŒØª Ù¾Ø±ÙˆÚ˜Ù‡</h3>

          <div className="shil-form-grid">
            <div className="shil-field">
              <label>Ø´Ù‡Ø± Ù¾Ø±ÙˆÚ˜Ù‡</label>
              <SmartCityInput
                value={city}
                onChange={(value) => { setCity(value); setManualOverride(false); }}
                onPick={pickCity}
                placeholder="Ø§ÙˆÙ„ Ø§Ø³Ù… Ø´Ù‡Ø± Ø±Ø§ Ø¨Ø²Ù†Ø› Ù…Ø«Ù„Ø§Ù‹ Ø§ØµØŒ Ø´ÛŒØŒ ØªÙ‡ØŒ ØªØ¨..."
              />
              <small className="shil-env-hint">
                Ø¨Ø§ Ø§Ù†ØªØ®Ø§Ø¨ Ø´Ù‡Ø± Ù…ÙˆØ±Ø¯ Ù†Ø¸Ø± Ø¯ÛŒØªØ§ÛŒ Ø§Ù‚Ù„ÛŒÙ…ÛŒ Ù¾ÛŒØ´â€ŒÙØ±Ø¶ Ø¯Ø± Ø¬Ø¯ÙˆÙ„ ÙˆØ§Ø±Ø¯ Ù…ÛŒâ€ŒØ´ÙˆØ¯.
              </small>
            </div>

            <div className="shil-field">
              <label>Ø¢Ø¯Ø±Ø³ Ù¾Ø±ÙˆÚ˜Ù‡</label>
              <input
                className="shil-input"
                value={address}
                onChange={(event) => setAddress(event.target.value)}
                placeholder="Ø§Ø®ØªÛŒØ§Ø±ÛŒØ› Ù…Ø«Ù„Ø§Ù‹ Ø´Ù‡Ø±Ú© ØµÙ†Ø¹ØªÛŒØŒ Ù¾Ø´Øªâ€ŒØ¨Ø§Ù…ØŒ Ù…Ø²Ø±Ø¹Ù‡ØŒ ÙˆÛŒÙ„Ø§..."
              />
            </div>

            <div className="shil-field">
              <label>Ù…Ø®ØªØµØ§Øª GPS</label>
              <div className="shil-gps-toggle">
                <button type="button" className={gpsMode === "auto" ? "active" : ""} onClick={() => setGpsMode("auto")}>Ø§Ø² Ø´Ù‡Ø±</button>
                <button type="button" className={gpsMode === "manual" ? "active" : ""} onClick={() => setGpsMode("manual")}>Ø¯Ø³ØªÛŒ</button>
                <button type="button" onClick={requestCurrentLocation}>GPS Ø¯Ø³ØªÚ¯Ø§Ù‡</button>
              </div>
              <div className="shil-gps-manual-grid">
                <input className="shil-input" value={latitude} onChange={(event) => { setGpsMode("manual"); setLatitude(event.target.value); }} placeholder="Latitude" inputMode="decimal" />
                <input className="shil-input" value={longitude} onChange={(event) => { setGpsMode("manual"); setLongitude(event.target.value); }} placeholder="Longitude" inputMode="decimal" />
              </div>
              <small className="shil-env-hint">
                {gpsStatus || (selectedCity ? `Ù…ÙˆÙ‚Ø¹ÛŒØª Ù¾ÛŒØ´â€ŒÙØ±Ø¶: ${selectedCity.name}ØŒ ${selectedCity.province}` : "Ø´Ù‡Ø± Ø±Ø§ Ø§Ø² Ù¾ÛŒØ´Ù†Ù‡Ø§Ø¯Ù‡Ø§ Ø§Ù†ØªØ®Ø§Ø¨ Ú©Ù† ÛŒØ§ GPS Ø¯Ø³ØªÚ¯Ø§Ù‡ Ø±Ø§ Ø¨Ø²Ù†.")}
              </small>
            </div>
          </div>
          <div className="shil-map-container shil-env-location-map"><img src="/assets/shil/map/iran-heatmap.webp" alt="Iran heating system map" /></div>
        </section>

        <section className="shil-env-card">
          <h3 className="shil-section-title">Ø´Ø±Ø§ÛŒØ· Ù†ØµØ¨</h3>
          <div className="shil-install-scroll">
            {installTypes.map((item) => (
              <button key={item.key} type="button" className={`shil-install-chip ${installType === item.key ? "active" : ""}`} onClick={() => setInstallType(item.key)}>
                {item.label}
              </button>
            ))}
          </div>
          <small className="shil-env-hint">{activeInstallType.description}</small>

          <div className="shil-manual-climate-grid shil-orientation-input-grid">
            <div className="shil-field"><label>Ø¬Ù‡Øª Ù†ØµØ¨ Ù¾Ù†Ù„ Â°</label><input className="shil-input" value={installAzimuthDeg} onChange={(event) => setInstallAzimuthDeg(event.target.value)} inputMode="decimal" placeholder="Ù¾ÛŒØ´â€ŒÙØ±Ø¶ Û±Û¸Û° Ø¬Ù†ÙˆØ¨" /><small className="shil-env-hint">Û° Ø´Ù…Ø§Ù„ØŒ Û¹Û° Ø´Ø±Ù‚ØŒ Û±Û¸Û° Ø¬Ù†ÙˆØ¨ØŒ Û²Û·Û° ØºØ±Ø¨Ø› Ø§ÛŒÙ† Ø¹Ø¯Ø¯ Ø¯Ø± Ø±Ø§Ù†Ø¯Ù…Ø§Ù† Ùˆ ØªÙ„ÙØ§Øª Ø§Ø¹Ù…Ø§Ù„ Ù…ÛŒâ€ŒØ´ÙˆØ¯.</small></div>
            <div className="shil-field"><label>Ø²Ø§ÙˆÛŒÙ‡ Ù†ØµØ¨ Ù¾Ù†Ù„ Â°</label><input className="shil-input" value={installTiltDeg} onChange={(event) => setInstallTiltDeg(event.target.value)} inputMode="decimal" placeholder={`Ù¾ÛŒØ´Ù†Ù‡Ø§Ø¯ÛŒ ${assessment.recommendedTiltDeg}Â°`} /><small className="shil-env-hint">Ø¹Ø¯Ø¯ Ø¯Ø³ØªÛŒ Ú©Ø§Ø±Ø¨Ø± Ø¬Ø§ÛŒÚ¯Ø²ÛŒÙ† Ø²Ø§ÙˆÛŒÙ‡ Ù¾ÛŒØ´Ù†Ù‡Ø§Ø¯ÛŒ Ùˆ ÙˆØ§Ø±Ø¯ Ù…ÙˆØªÙˆØ± Ù…Ø­Ø§Ø³Ø¨Ø§Øª Ù…ÛŒâ€ŒØ´ÙˆØ¯.</small></div>
          </div>
          <div className="shil-climate-grid shil-orientation-factor-grid"><div className="shil-climate-box"><span>Ø§ÙØª Ø¬Ù‡Øª</span><strong>{assessment.orientationLossPercent}%</strong></div><div className="shil-climate-box"><span>Ø§ÙØª Ø²Ø§ÙˆÛŒÙ‡</span><strong>{assessment.tiltLossPercent}%</strong></div><div className="shil-climate-box"><span>Ø¶Ø±ÛŒØ¨ Ø¬Ù‡Øª/Ø²Ø§ÙˆÛŒÙ‡</span><strong>{Math.round((assessment.orientationEfficiency || 1) * 100)}%</strong></div><div className="shil-climate-box"><span>Ø±Ø§Ù†Ø¯Ù…Ø§Ù† Ù†Ù‡Ø§ÛŒÛŒ Ù…Ø­ÛŒØ·ÛŒ</span><strong>{Math.round((assessment.effectiveEfficiency || 1) * 100)}%</strong></div></div>

          <div className="shil-upload-grid shil-install-upload-grid">
            <div className="shil-upload-box shil-smart-upload-box">
              <span>Ø¢Ù¾Ù„ÙˆØ¯ Ø¬Ù‡Øªâ€ŒÙ†Ù…Ø§</span>
              <div className="shil-upload-choice-row">
                <button type="button" className={compassUploadChoice === "gallery" ? "active" : ""} onClick={() => setCompassUploadChoice("gallery")}>Ø§Ù†ØªØ®Ø§Ø¨ Ø§Ø² Ú¯Ø§Ù„Ø±ÛŒ</button>
                <button type="button" className={compassUploadChoice === "later" ? "active" : ""} onClick={() => setCompassUploadChoice("later")}>Ø¨Ø¹Ø¯Ø§Ù‹</button>
              </div>
              {compassUploadChoice === "gallery" ? (
                <input type="file" accept="image/*" onChange={handleCompassUpload} />
              ) : null}
              {compassPreview ? (
                <div className="shil-orientation-frame" aria-label="Ù¾ÛŒØ´â€ŒÙ†Ù…Ø§ÛŒØ´ Ø¬Ù‡Øªâ€ŒÙ†Ù…Ø§ Ø¨Ø§ Ù…Ø­ÙˆØ±Ù‡Ø§ÛŒ Ø¬ØºØ±Ø§ÙÛŒØ§ÛŒÛŒ">
                  {Object.entries({ north: "ÙˆØ±ÙˆØ¯ÛŒ Ø§ØµÙ„ÛŒ Ø¬Ù‡Øª", east: "Ù„Ø¨Ù‡ Ø±Ø§Ø³Øª Ù…Ø­Ù„ Ù†ØµØ¨", south: "Ø¬Ù‡Øª Ø¨Ù‡ÛŒÙ†Ù‡ Ù¾Ù†Ù„", west: "Ù„Ø¨Ù‡ Ú†Ù¾ Ù…Ø­Ù„ Ù†ØµØ¨" }).map(([slot, hint]) => (
                    <label key={slot} className={`shil-orientation-label shil-orientation-${slot}`}>
                      <select className="shil-orientation-select" value={directionSlots[slot]} onChange={(event) => setDirectionSlots((prev) => ({ ...prev, [slot]: event.target.value }))}>
                        {directionOptions.map((item) => <option key={item.key} value={item.key}>{item.label} {item.deg}Â°</option>)}
                      </select>
                      <small>{hint}</small>
                    </label>
                  ))}
                  <div className="shil-orientation-image-shell">
                    <img src={compassPreview} alt="Compass preview" />
                  </div>
                </div>
              ) : null}
            </div>

            <label className="shil-upload-box shil-site-upload-box">
              <span>ØªØµØ§ÙˆÛŒØ± Ù…Ø­Ù„ Ù†ØµØ¨</span>
              <input type="file" accept="image/*" multiple onChange={handleSiteUpload} />
              {sitePreviews.length ? (
                <div className="shil-site-preview-grid shil-site-preview-contain-grid">
                  {sitePreviews.map((src, index) => (
                    <figure key={index} className="shil-site-preview-card">
                      <img src={src} alt={`Site preview ${index + 1}`} />
                      <figcaption>ØªØµÙˆÛŒØ± {index + 1}</figcaption>
                    </figure>
                  ))}
                </div>
              ) : null}
            </label>
          </div>
          <button type="button" className="shil-mini-action shil-save-images-btn" onClick={saveInstallationImages}>Ø°Ø®ÛŒØ±Ù‡ ØªØµØ§ÙˆÛŒØ± Ù†ØµØ¨</button>
          <small className="shil-env-hint">{savedSiteImageCount || savedCompassImage ? `${savedSiteImageCount} ØªØµÙˆÛŒØ± Ù…Ø­Ù„ Ù†ØµØ¨ Ùˆ ${savedCompassImage ? "Ø¬Ù‡Øªâ€ŒÙ†Ù…Ø§" : "Ø¨Ø¯ÙˆÙ† Ø¬Ù‡Øªâ€ŒÙ†Ù…Ø§"} Ø°Ø®ÛŒØ±Ù‡ Ø´Ø¯Ù‡ Ø§Ø³Øª.` : "ØªØµØ§ÙˆÛŒØ± Ù¾Ø³ Ø§Ø² Ø§Ù†ØªØ®Ø§Ø¨ØŒ Ø¯Ø± Ú©Ø§Ø¯Ø± Ú©Ø§Ù…Ù„ Ùˆ Ø¨Ø¯ÙˆÙ† Ø¨Ø±Ø´ Ø¯ÛŒØ¯Ù‡ Ù…ÛŒâ€ŒØ´ÙˆÙ†Ø¯."}</small>
        </section>

        <section className="shil-env-card">
          <h3 className="shil-section-title">Ø¯Ø§Ø¯Ù‡â€ŒÙ‡Ø§ÛŒ Ø§Ù‚Ù„ÛŒÙ…ÛŒ</h3>

          <div className="shil-manual-climate-grid">
            <div className="shil-field"><label>Ø¯Ù…Ø§ÛŒ Ù…ÛŒØ§Ù†Ú¯ÛŒÙ† Â°C</label><input className="shil-input" value={manualClimate.temperature} onChange={(event) => updateClimate("temperature", event.target.value)} inputMode="decimal" /></div>
            <div className="shil-field"><label>Ø­Ø¯Ø§Ù‚Ù„ Ø¯Ù…Ø§ Â°C</label><input className="shil-input" value={manualClimate.temperatureMinC} onChange={(event) => updateClimate("temperatureMinC", event.target.value)} inputMode="decimal" /></div>
            <div className="shil-field"><label>Ø­Ø¯Ø§Ú©Ø«Ø± Ø¯Ù…Ø§ Â°C</label><input className="shil-input" value={manualClimate.temperatureMaxC} onChange={(event) => updateClimate("temperatureMaxC", event.target.value)} inputMode="decimal" /></div>
            <div className="shil-field"><label>Ø§Ø±ØªÙØ§Ø¹ Ø§Ø² Ø³Ø·Ø­ Ø¯Ø±ÛŒØ§ m</label><input className="shil-input" value={manualClimate.altitude} onChange={(event) => updateClimate("altitude", event.target.value)} inputMode="decimal" /></div>
            <div className="shil-field"><label>Ø±Ø·ÙˆØ¨Øª %</label><input className="shil-input" value={manualClimate.humidity} onChange={(event) => updateClimate("humidity", event.target.value)} inputMode="decimal" /></div>
            <div className="shil-field"><label>Ø³Ø§Ø¹Øª Ø¢ÙØªØ§Ø¨ÛŒ Ù…Ø¤Ø«Ø±</label><input className="shil-input" value={manualClimate.peakSunHours} onChange={(event) => updateClimate("peakSunHours", event.target.value)} inputMode="decimal" disabled={domain !== "solar"} /></div>
          </div>
          <button type="button" className="shil-mini-action shil-climate-restore-bottom" onClick={restoreCityClimate}>Ø¨Ø§Ø²Ú¯Ø´Øª Ø¨Ù‡ Ø§Ù‚Ù„ÛŒÙ… Ø´Ù‡Ø±</button>
        </section>

        <section className="shil-env-card">
          <h3 className="shil-section-title">ØªØ­Ù„ÛŒÙ„ Ù…Ù‡Ù†Ø¯Ø³ÛŒ Ø®ÙˆØ¯Ú©Ø§Ø±</h3>
          <div className="shil-climate-grid">
            <div className="shil-climate-box"><span>Ø²Ø§ÙˆÛŒÙ‡ Ù¾ÛŒØ´Ù†Ù‡Ø§Ø¯ÛŒ Ù¾Ù†Ù„</span><strong>{assessment.recommendedTiltDeg}Â°</strong></div>
            <div className="shil-climate-box"><span>Ø²Ø§ÙˆÛŒÙ‡ Ø§Ø¹Ù…Ø§Ù„â€ŒØ´Ø¯Ù‡</span><strong>{assessment.selectedTiltDeg}Â°</strong></div>
            <div className="shil-climate-box"><span>Ø¬Ù‡Øª Ù¾ÛŒØ´Ù†Ù‡Ø§Ø¯ÛŒ</span><strong>{assessment.recommendedAzimuthDeg}Â° Ø¬Ù†ÙˆØ¨</strong></div>
            <div className="shil-climate-box"><span>Ø¬Ù‡Øª Ø§Ø¹Ù…Ø§Ù„â€ŒØ´Ø¯Ù‡</span><strong>{assessment.selectedAzimuthDeg}Â°</strong></div>
            <div className="shil-climate-box"><span>Ø§ÙØª Ø­Ø±Ø§Ø±ØªÛŒ</span><strong>{assessment.thermalDeratePercent}%</strong></div>
            <div className="shil-climate-box"><span>Ø§ÙØª Ø¬Ù‡Øª/Ø²Ø§ÙˆÛŒÙ‡</span><strong>{assessment.totalOrientationLossPercent}%</strong></div>
            <div className="shil-climate-box"><span>Ø±ÛŒØ³Ú© Ø®ÙˆØ±Ø¯Ú¯ÛŒ</span><strong>{assessment.corrosionRisk}</strong></div>
            <div className="shil-climate-box"><span>Ø¯Ø±Ø¬Ù‡ Ø­ÙØ§Ø¸Øª</span><strong>{assessment.recommendedIngressProtection}</strong></div>
            <div className="shil-climate-box"><span>ÙˆØ¶Ø¹ÛŒØª Ù…Ø³ÛŒØ±</span><strong>{routeStatusLabel}</strong></div>
          </div>
          {assessment.warnings.length ? (
            <div className="shil-warning-list">
              {assessment.warnings.map((item, index) => <p key={index}>{item}</p>)}
            </div>
          ) : <small className="shil-env-hint">Ù‡ÛŒÚ† Ù‡Ø´Ø¯Ø§Ø± Ù…Ø­ÛŒØ·ÛŒ Ø¬Ø¯ÛŒ Ø«Ø¨Øª Ù†Ø´Ø¯Ù‡ Ø§Ø³Øª.</small>}
        </section>

        {validationMessage ? <div className="shil-env-error">{validationMessage}</div> : null}
        <button type="button" className="shil-primary-wide" onClick={confirmEnvironment}>ØªØ£ÛŒÛŒØ¯ Ø´Ø±Ø§ÛŒØ· Ù…Ø­ÛŒØ·ÛŒ Ùˆ Ø§Ø¯Ø§Ù…Ù‡</button>
      </div>
    </ShilPageShell>
  );
}
