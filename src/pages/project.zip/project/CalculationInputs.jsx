import { useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import ShilPageShell from "../../components/ShilPageShell.jsx";
import ProjectMiniRail from "../../components/ProjectMiniRail.jsx";
import { consumerEquipmentLibrary, searchConsumerEquipment } from "../../data/catalogs/consumerEquipmentLibrary.js";
import { buildScenarioCalculationInput } from "../../core/scenario/scenarioToEngineeringForm.js";
import { METHOD_LABELS, persistSurfaceLoadPreview as persistLoadEngineResult, runSurfaceLoadPreview as runLoadEngine, runSurfacePvPreview as runUnifiedPvForUi } from "../../calculationGateway/surfacePreviewData.js";
import { SHIL_SOLAR_PANELS, SHIL_LITHIUM_BATTERIES } from "../../data/shilSolarBanks.js";
import { isScenarioFlowFor, startUtilityGateway } from "../../workflow/flowIsolation.js";

function readDraft(key) {
  try { return JSON.parse(localStorage.getItem(key) || "null"); }
  catch { return null; }
}

function normalizePersianInput(value) {
  return String(value ?? "")
    .replace(/[Û°-Û¹]/g, (d) => "Û°Û±Û²Û³Û´ÛµÛ¶Û·Û¸Û¹".indexOf(d))
    .replace(/[Ù -Ù©]/g, (d) => "Ù Ù¡Ù¢Ù£Ù¤Ù¥Ù¦Ù§Ù¨Ù©".indexOf(d))
    .replace(/Ù«/g, ".")
    .replace(/Ù¬/g, "")
    .replace(/,/g, "")
    .trim();
}

function toNumber(value, fallback = 0) {
  const n = Number(normalizePersianInput(value));
  return Number.isFinite(n) ? n : fallback;
}

function clampNumber(value, fallback, min, max) {
  const n = toNumber(value, fallback);
  if (!Number.isFinite(n)) return fallback;
  return Math.max(min, Math.min(max, n));
}

function getEnvironmentSolarDefaults(environment = {}, assessment = {}) {
  const psh = clampNumber(environment.peakSunHours ?? environment.sunHours ?? assessment.peakSunHours, 5, 2.5, 7.5);
  const thermal = clampNumber(environment.thermalDeratePercent ?? assessment.thermalDeratePercent, 6, 0, 25);
  const soiling = clampNumber(environment.soilingLossPercent ?? assessment.soilingLossPercent, 4, 0, 18);
  const wiring = clampNumber(environment.wiringLossPercent ?? assessment.wiringLossPercent, 3, 0, 8);
  const orientation = clampNumber(environment.totalOrientationLossPercent ?? assessment.totalOrientationLossPercent, 0, 0, 55);
  const tilt = clampNumber(environment.tiltLossPercent ?? assessment.tiltLossPercent, 0, 0, 20);
  const azimuth = clampNumber(environment.orientationLossPercent ?? assessment.orientationLossPercent, 0, 0, 45);
  const safety = 3;
  const totalLoss = clampNumber(environment.totalLossPercent ?? assessment.totalLossPercent ?? (thermal + soiling + wiring + orientation + safety), 15, 4, 60);
  const effectiveEfficiency = clampNumber(environment.effectiveEfficiency ?? assessment.effectiveEfficiency ?? (1 - totalLoss / 100), 0.8, 0.35, 1);
  return { psh, totalLoss, thermal, soiling, wiring, orientation, tilt, azimuth, safety, effectiveEfficiency };
}

function mergeItemWithOverride(item, override = {}) {
  return {
    ...item,
    ...override,
    quantity: Number(override.quantity ?? item.quantity ?? 1) || 1,
    usageHoursPerDay: Number(override.usageHoursPerDay ?? item.usageHoursPerDay ?? 0) || 0,
    hasSoftStarter: Boolean(override.hasSoftStarter ?? item.hasSoftStarter ?? false),
  };
}

function matchScenarioEquipmentItems(scenario) {
  if (!scenario?.requiredEquipment?.recommendedItems?.length) return [];
  const wanted = scenario.requiredEquipment.recommendedItems.map((item) => String(item).trim()).filter(Boolean);
  const picked = [];
  const used = new Set();

  for (const label of wanted) {
    const exact = consumerEquipmentLibrary.find((item) =>
      !used.has(item.id) && (item.title.includes(label) || item.category.includes(label))
    );
    const fallback = consumerEquipmentLibrary.find((item) =>
      !used.has(item.id) && (label.includes(item.category) || item.title.includes(label.split(" ")[0] || label))
    );
    const selected = exact || fallback;
    if (selected) {
      used.add(selected.id);
      picked.push(selected);
    }
  }

  if (!picked.length && scenario.domain === "solar") {
    return consumerEquipmentLibrary.filter((item) => ["eq-001", "eq-003", "eq-022"].includes(item.id));
  }

  if (!picked.length && scenario.domain === "emergency") {
    return consumerEquipmentLibrary.filter((item) =>
      ["Ù„Ø§Ù…Ù¾ LED", "Ø±ÙˆØ´Ù†Ø§ÛŒÛŒ Ø§Ø¶Ø·Ø±Ø§Ø±ÛŒ", "Ù…ÙˆØ¯Ù… Ø§ÛŒÙ†ØªØ±Ù†Øª", "Ø¯ÙˆØ±Ø¨ÛŒÙ† Ù…Ø¯Ø§Ø±Ø¨Ø³ØªÙ‡", "ÛŒØ®Ú†Ø§Ù„ Ø®Ø§Ù†Ú¯ÛŒ"].some((label) => item.title.includes(label))
    ).slice(0, 5);
  }

  return picked;
}

function buildScenarioEquipmentOverrides(scenario, items) {
  if (!items.length) return {};
  const targetPowerW = Number(scenario?.loadEstimate || 0);
  const targetDailyWh = Number(scenario?.dailyEnergyWh || 0);
  const basePowerW = items.reduce((sum, item) => sum + Number(item.ratedPowerW || 0), 0) || 1;
  const baseDailyWh = items.reduce((sum, item) => sum + Number(item.energyDailyWh || 0), 0) || 1;
  const powerFactor = targetPowerW > 0 ? Math.max(1, Math.round(targetPowerW / basePowerW)) : 1;
  const energyFactor = targetDailyWh > 0 ? Math.max(1, Math.round(targetDailyWh / baseDailyWh)) : 1;
  const scenarioFactor = Math.max(1, Math.min(20, Math.round((powerFactor + energyFactor) / 2)));

  return Object.fromEntries(items.map((item) => [
    item.id,
    {
      quantity: scenarioFactor,
      usageHoursPerDay: item.usageHoursPerDay,
      hasSoftStarter: false,
      scenarioSeeded: true,
    },
  ]));
}

export default function CalculationInputs() {
  const navigate = useNavigate();
  const params = useParams();
  const domain = params.domain || localStorage.getItem("shil:calculationDomain") || localStorage.getItem("shil:scenarioDomain") || "solar";
  const method = params.method || localStorage.getItem("shil:calculationMethod") || "equipment";

  const [query, setQuery] = useState("");
  const [isEquipmentPickerOpen, setIsEquipmentPickerOpen] = useState(false);
  const [scaleWarning, setScaleWarning] = useState("");
  const scenario = useMemo(() => readDraft("shil:selectedScenario"), []);
  const scenarioSeededItems = useMemo(() => matchScenarioEquipmentItems(scenario), [scenario]);
  const isReadyScenarioEquipmentFlow = isScenarioFlowFor(domain) && method === "equipment" && ["solar", "emergency"].includes(domain);

  const [selectedIds, setSelectedIds] = useState(() => new Set(isReadyScenarioEquipmentFlow ? scenarioSeededItems.map((item) => item.id) : []));
  const [itemOverrides, setItemOverrides] = useState(() => isReadyScenarioEquipmentFlow ? buildScenarioEquipmentOverrides(scenario, scenarioSeededItems) : {});
  const [showExpert, setShowExpert] = useState(false);
  const [manualEnergyKWh, setManualEnergyKWh] = useState("");
  const [manualPowerW, setManualPowerW] = useState("");
  const [manualCurrentA, setManualCurrentA] = useState("");
  const [manualVoltage, setManualVoltage] = useState(domain === "emergency" ? "220" : "220");
  const [manualHours, setManualHours] = useState(domain === "emergency" ? "6" : "5");
  const [profileVoltage, setProfileVoltage] = useState("220");
  const [profilePowerW, setProfilePowerW] = useState("1000");
  const [profileMorningKWh, setProfileMorningKWh] = useState("1");
  const [profileNoonKWh, setProfileNoonKWh] = useState("1");
  const [profileEveningKWh, setProfileEveningKWh] = useState("2");
  const [profileNightKWh, setProfileNightKWh] = useState("1");
  const [profileStartFactor, setProfileStartFactor] = useState("1.6");

  const environment = useMemo(() => readDraft("shil:environmentDraft") || {}, []);
  const environmentAssessment = useMemo(() => readDraft("shil:environmentAssessment") || {}, []);
  const envSolarDefaults = useMemo(() => getEnvironmentSolarDefaults(environment, environmentAssessment), [environment, environmentAssessment]);

  const defaultPanel = SHIL_SOLAR_PANELS.find((p) => p.powerW === 620) || SHIL_SOLAR_PANELS[0];
  const defaultBattery = SHIL_LITHIUM_BATTERIES.find((b) => b.nominalVoltage === 48 && b.capacityAh === 200) || SHIL_LITHIUM_BATTERIES[0];
  const [selectedPanelId, setSelectedPanelId] = useState(defaultPanel?.id || "");
  const [panelCount, setPanelCount] = useState("10");
  const [psh, setPsh] = useState(String(envSolarDefaults.psh));
  const [lossPercent, setLossPercent] = useState(String(envSolarDefaults.totalLoss));
  const [dailyLoadKWh, setDailyLoadKWh] = useState("");
  const [acVoltageRoute, setAcVoltageRoute] = useState("220");
  const [inverterSplitCount, setInverterSplitCount] = useState("1");
  const [needsBattery, setNeedsBattery] = useState(false);
  const [daysAutonomy, setDaysAutonomy] = useState("1");
  const [batteryId, setBatteryId] = useState(defaultBattery?.id || "");
  const [batteryDod, setBatteryDod] = useState(String(defaultBattery?.usableDod || 0.85));
  const [systemEta, setSystemEta] = useState(String(defaultBattery?.efficiency || 0.94));

  const items = useMemo(() => {
    const results = searchConsumerEquipment(query);
    return results.slice(0, 250);
  }, [query]);

  const selectedItems = useMemo(() => {
    return consumerEquipmentLibrary
      .filter((item) => selectedIds.has(item.id))
      .map((item) => mergeItemWithOverride(item, itemOverrides[item.id]));
  }, [selectedIds, itemOverrides]);

  const selectedPanel = useMemo(() => SHIL_SOLAR_PANELS.find((item) => item.id === selectedPanelId) || defaultPanel || {}, [selectedPanelId, defaultPanel]);
  const selectedBattery = useMemo(() => SHIL_LITHIUM_BATTERIES.find((item) => item.id === batteryId) || defaultBattery || {}, [batteryId, defaultBattery]);
  const panelPowerW = toNumber(selectedPanel.powerW, 0);
  const batteryUnitKWh = toNumber(selectedBattery.energyWh || (toNumber(selectedBattery.nominalVoltage, 0) * toNumber(selectedBattery.capacityAh, 0)), 0) / 1000;
  const totalPanelPowerW = toNumber(panelPowerW, 0) * toNumber(panelCount, 0);
  const inverterCountNormalized = Math.max(1, Math.round(toNumber(inverterSplitCount, 1)));
  const panelCountNormalized = Math.max(0, Math.round(toNumber(panelCount, 0)));
  const rawPvDailyKWh = Number(((totalPanelPowerW / 1000) * toNumber(psh, 0)).toFixed(2));
  const lossRatio = Math.min(0.95, Math.max(0, toNumber(lossPercent, 0) / 100));
  const effectivePanelPowerW = Number((totalPanelPowerW * (1 - lossRatio)).toFixed(2));
  const calculatedPvDailyKWh = Number((rawPvDailyKWh * (1 - lossRatio)).toFixed(2));
  // Ù…Ø¹ÛŒØ§Ø± ÙˆØ±ÙˆØ¯ Ø¨Ù‡ Ù…Ø³ÛŒØ± Ù†ÛŒØ±ÙˆÚ¯Ø§Ù‡ÛŒ ÙÙ‚Ø· ØªÙˆØ§Ù† Ù…ÙˆØ«Ø± Ù¾Ø³ Ø§Ø² ØªÙ„ÙØ§Øª/Ø±Ø§Ù†Ø¯Ù…Ø§Ù† Ù…Ø­ÛŒØ·ÛŒ Ø§Ø³ØªØ›
  // Ø¶Ø±ÛŒØ¨ Ø±Ø§Ù‡â€ŒØ§Ù†Ø¯Ø§Ø²ÛŒ Ùˆ ØªÙˆØ§Ù† Ø®Ø§Ù… Ù¾Ù†Ù„ Ù†Ø¨Ø§ÛŒØ¯ Ù…Ø³ÛŒØ± Ø±Ø§ Ù†ÛŒØ±ÙˆÚ¯Ø§Ù‡ÛŒ Ú©Ù†Ù†Ø¯.
  const isUtilityPanelScale = effectivePanelPowerW > 30000;
  const isUtilityGateway = domain === "utility";

  const defaultPanelDistribution = useMemo(() => {
    const invCount = Math.max(1, Math.round(toNumber(inverterSplitCount, 1)));
    const total = Math.max(0, Math.round(toNumber(panelCount, 0)));
    const base = Math.floor(total / invCount);
    const rest = total % invCount;
    return Array.from({ length: invCount }, (_, index) => base + (index < rest ? 1 : 0));
  }, [panelCount, inverterSplitCount]);

  const [showManualPanelSplit, setShowManualPanelSplit] = useState(false);
  const [manualPanelDistribution, setManualPanelDistribution] = useState([]);

  useEffect(() => {
    setManualPanelDistribution((prev) => {
      const invCount = Math.max(1, Math.round(toNumber(inverterSplitCount, 1)));
      const next = Array.from({ length: invCount }, (_, index) => toNumber(prev[index] ?? defaultPanelDistribution[index] ?? 0, 0));
      return next;
    });
  }, [inverterSplitCount, defaultPanelDistribution]);

  const activePanelDistribution = showManualPanelSplit ? manualPanelDistribution : defaultPanelDistribution;
  const distributionTotal = activePanelDistribution.reduce((sum, value) => sum + toNumber(value, 0), 0);
  const distributionMismatch = showManualPanelSplit && distributionTotal !== panelCountNormalized;

  const inverterPanelLayouts = useMemo(() => {
    return activePanelDistribution.map((panelQty, index) => {
      const count = Math.max(0, Math.round(toNumber(panelQty, 0)));
      const series = count > 0 ? Math.max(1, Math.min(count, Math.round(Math.sqrt(count)))) : 0;
      const parallel = count > 0 ? Math.ceil(count / Math.max(1, series)) : 0;
      const powerKW = Number(((count * panelPowerW) / 1000).toFixed(2));
      return { index: index + 1, count, series, parallel, powerKW };
    });
  }, [activePanelDistribution, panelPowerW]);


  const profileBucketsWh = useMemo(() => ({
    morning: Math.max(0, toNumber(profileMorningKWh, 0) * 1000),
    noon: Math.max(0, toNumber(profileNoonKWh, 0) * 1000),
    evening: Math.max(0, toNumber(profileEveningKWh, 0) * 1000),
    night: Math.max(0, toNumber(profileNightKWh, 0) * 1000),
  }), [profileMorningKWh, profileNoonKWh, profileEveningKWh, profileNightKWh]);

  const profileTotalEnergyWh = useMemo(() => Object.values(profileBucketsWh).reduce((sum, value) => sum + value, 0), [profileBucketsWh]);
  const profilePeakBucketWh = useMemo(() => Math.max(...Object.values(profileBucketsWh), 0), [profileBucketsWh]);
  const profilePeakPowerW = useMemo(() => Math.max(toNumber(profilePowerW, 0), profilePeakBucketWh / 3), [profilePowerW, profilePeakBucketWh]);
  const profileSurgePowerW = useMemo(() => Math.round(profilePeakPowerW * Math.max(1, toNumber(profileStartFactor, 1.6))), [profilePeakPowerW, profileStartFactor]);

  const profileLoadProfile = useMemo(() => ({
    buckets: profileBucketsWh,
    peakBucket: Object.entries(profileBucketsWh).sort((a, b) => b[1] - a[1])[0]?.[0] || "evening",
    peakHours: [18, 19, 20, 21],
    simultaneityFactor: 1,
  }), [profileBucketsWh]);

  const enginePreview = useMemo(() => {
    const voltage = toNumber(method === "solar_panel_power" ? acVoltageRoute : method === "profile" ? profileVoltage : manualVoltage || 220, 220);
    const powerFromCurrent = method === "current" && manualCurrentA ? toNumber(manualCurrentA, 0) * voltage : 0;
    const energyFromManual = method === "energy" && manualEnergyKWh ? toNumber(manualEnergyKWh, 0) * 1000 : method === "profile" ? profileTotalEnergyWh : 0;
    const powerFromManual = method === "power" && manualPowerW ? toNumber(manualPowerW, 0) : method === "profile" ? profilePeakPowerW : 0;
    const solarPanelEnergyWh = method === "solar_panel_power" ? calculatedPvDailyKWh * 1000 : 0;
    const solarPanelPowerW = method === "solar_panel_power" ? totalPanelPowerW : 0;
    return runLoadEngine({
      domain,
      method,
      scenario,
      environment,
      environmentAssessment,
      selectedItems,
      voltageAC: voltage,
      phaseAC: voltage >= 380 ? "three" : "single",
      manualEnergyWh: energyFromManual || solarPanelEnergyWh,
      manualPowerW: powerFromCurrent || powerFromManual || solarPanelPowerW,
      manualHours: toNumber(method === "profile" ? 1 : manualHours || psh || 0, 0),
      manualSurgeW: method === "profile" ? profileSurgePowerW : 0,
      loadProfile: method === "profile" ? profileLoadProfile : undefined,
    });
  }, [domain, method, scenario, environment, environmentAssessment, selectedItems, manualEnergyKWh, manualPowerW, manualCurrentA, manualVoltage, manualHours, panelPowerW, panelCount, psh, acVoltageRoute, totalPanelPowerW, calculatedPvDailyKWh, profileVoltage, profileTotalEnergyWh, profilePeakPowerW, profileSurgePowerW, profileLoadProfile]);

  const solarPanelPreview = useMemo(() => {
    if (method !== "solar_panel_power") return null;
    return runUnifiedPvForUi({
      load: { method, totalPowerW: totalPanelPowerW, totalEnergyKWh: calculatedPvDailyKWh, voltageAC: toNumber(acVoltageRoute, 220) },
      environment,
      settings: {
        method: "solar_panel_power",
        calculationMethod: "solar_panel_power",
        panelId: selectedPanelId,
        panelCount: Number(panelCount || 0),
        outputAcVoltage: toNumber(acVoltageRoute, 220),
      },
      solarPanelPowerInput: {
        selectedPanelId,
        panelPowerW: Number(panelPowerW || 0),
        panelCount: Number(panelCount || 0),
        totalPanelPowerW,
        psh: Number(psh || 0),
        lossPercent: Number(lossPercent || 0),
        generatedDailyKWh: calculatedPvDailyKWh,
        acVoltageRoute: toNumber(acVoltageRoute, 220),
      },
    });
  }, [method, selectedPanelId, panelPowerW, panelCount, psh, lossPercent, environment, acVoltageRoute, totalPanelPowerW, calculatedPvDailyKWh]);

  const toggleItem = (item) => {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(item.id)) next.delete(item.id);
      else {
        next.add(item.id);
        setItemOverrides((old) => ({
          ...old,
          [item.id]: {
            quantity: old[item.id]?.quantity ?? 1,
            usageHoursPerDay: old[item.id]?.usageHoursPerDay ?? item.usageHoursPerDay,
            hasSoftStarter: old[item.id]?.hasSoftStarter ?? false,
          },
        }));
      }
      return next;
    });
  };

  const patchOverride = (id, patch) => {
    setItemOverrides((prev) => ({ ...prev, [id]: { ...(prev[id] || {}), ...patch } }));
  };

  const applySmartDetails = () => {
    setShowExpert(true);
    setItemOverrides((prev) => {
      const next = { ...prev };
      consumerEquipmentLibrary.forEach((item) => {
        if (!selectedIds.has(item.id)) return;
        const isMotor = item.type === "inductive" || Number(item.startupFactor || item.surgeFactor || 1) > 1.7;
        next[item.id] = {
          ...(next[item.id] || {}),
          quantity: next[item.id]?.quantity ?? 1,
          usageHoursPerDay: next[item.id]?.usageHoursPerDay ?? item.usageHoursPerDay,
          simultaneityFactor: next[item.id]?.simultaneityFactor ?? item.simultaneityFactor ?? item.diversityFactor ?? 1,
          powerFactor: next[item.id]?.powerFactor ?? item.powerFactor ?? (isMotor ? 0.82 : 0.95),
          isMotor,
          hasSoftStarter: next[item.id]?.hasSoftStarter ?? false,
          loadKind: isMotor ? "motor" : "resistive/electronic",
        };
      });
      return next;
    });
  };

  const goToUtilityGateway = () => {
    startUtilityGateway("solar-panel-power-over-30kw");
    navigate("/new-project/system");
  };

  const confirmLoad = () => {
    if (method === "solar_panel_power" && distributionMismatch) {
      setScaleWarning(`Ø¬Ù…Ø¹ Ù¾Ù†Ù„â€ŒÙ‡Ø§ÛŒ ØªÙ‚Ø³ÛŒÙ…â€ŒØ´Ø¯Ù‡ Ø¨Ø§ÛŒØ¯ Ø¨Ø±Ø§Ø¨Ø± ${panelCountNormalized} Ø¨Ø§Ø´Ø¯. Ù…Ù‚Ø¯Ø§Ø± ÙØ¹Ù„ÛŒ ${distributionTotal} Ø§Ø³Øª.`);
      return;
    }
    if (method === "solar_panel_power" && isUtilityPanelScale && !isUtilityGateway) {
      setScaleWarning("ØªÙˆØ§Ù† Ù¾Ù†Ù„â€ŒÙ‡Ø§ÛŒ ÙˆØ§Ø±Ø¯Ø´Ø¯Ù‡ Ø§Ø² Û³Û°kW Ø¹Ø¨ÙˆØ± Ú©Ø±Ø¯Ù‡ Ø§Ø³Øª. Ø¨Ø±Ø§ÛŒ Ø¬Ù„ÙˆÚ¯ÛŒØ±ÛŒ Ø§Ø² Ø´Ù„ÙˆØºÛŒ Ùˆ Ø®Ø·Ø§ÛŒ Ù…Ø³ÛŒØ±ØŒ Ø§Ø¯Ø§Ù…Ù‡ Ø·Ø±Ø§Ø­ÛŒ Ø¨Ø§ÛŒØ¯ Ø§Ø² Ø¯Ø±Ú¯Ø§Ù‡ Ù…Ø³ØªÙ‚Ù„ Ù†ÛŒØ±ÙˆÚ¯Ø§Ù‡ÛŒ Ø§Ù†Ø¬Ø§Ù… Ø´ÙˆØ¯.");
      return;
    }

    if (method !== "solar_panel_power") {
      localStorage.removeItem("shil:solarPanelPowerInput");
      localStorage.removeItem("shil:solarPanelPowerPreview");
    }

    if (method === "solar_panel_power") {
      localStorage.setItem("shil:solarPanelPowerInput", JSON.stringify({
        selectedPanelId,
        panelTitle: selectedPanel.title,
        panelPowerW: Number(panelPowerW || 0),
        panelCount: Number(panelCount || 0),
        totalPanelPowerW,
        psh: Number(psh || 0),
        lossPercent: Number(lossPercent || 0),
        effectiveEfficiencyPercent: Number((100 - toNumber(lossPercent, 0)).toFixed(1)),
        effectivePanelPowerW,
        environmentalSource: {
          city: environment?.city,
          peakSunHours: environment?.peakSunHours,
          soilingLossPercent: environment?.soilingLossPercent,
          thermalDeratePercent: environment?.thermalDeratePercent,
          defaults: envSolarDefaults,
        },
        rawDailyEnergyKWh: rawPvDailyKWh,
        generatedDailyKWh: calculatedPvDailyKWh,
        usableDailyEnergyKWh: calculatedPvDailyKWh,
        acVoltageRoute: toNumber(acVoltageRoute, 220),
        inverterSplitCount: inverterCountNormalized,
        inverterPanelDistribution: activePanelDistribution.map((value) => toNumber(value, 0)),
        manualPanelSplit: Boolean(showManualPanelSplit),
        isUtilityPanelScale,
        utilityScaleBasis: "effective_after_losses",
      }));
      localStorage.setItem("shil:solarPanelPowerPreview", JSON.stringify(solarPanelPreview));
      const unifiedPreview = runUnifiedPvForUi({
        load: { method, totalPowerW: totalPanelPowerW, totalEnergyKWh: calculatedPvDailyKWh, voltageAC: toNumber(acVoltageRoute, 220) },
        environment,
        settings: { method: "solar_panel_power", calculationMethod: "solar_panel_power", panelId: selectedPanelId, panelCount: Number(panelCount || 0), outputAcVoltage: toNumber(acVoltageRoute, 220) },
        solarPanelPowerInput: {
          selectedPanelId,
          panelPowerW: Number(panelPowerW || 0),
          panelCount: Number(panelCount || 0),
          totalPanelPowerW,
          psh: Number(psh || 0),
          lossPercent: Number(lossPercent || 0),
          generatedDailyKWh: calculatedPvDailyKWh,
          acVoltageRoute: toNumber(acVoltageRoute, 220),
        },
      });
      localStorage.setItem("shil:unifiedPvEngineResult:input", JSON.stringify(unifiedPreview));
    }

    const result = persistLoadEngineResult({
      domain,
      method,
      scenario,
      environment,
      environmentAssessment,
      selectedItems,
      voltageAC: toNumber(method === "solar_panel_power" ? acVoltageRoute : method === "profile" ? profileVoltage : manualVoltage || 220, 220),
      phaseAC: toNumber(method === "solar_panel_power" ? acVoltageRoute : method === "profile" ? profileVoltage : manualVoltage || 220, 220) >= 380 ? "three" : "single",
      manualEnergyWh: method === "energy" && manualEnergyKWh ? toNumber(manualEnergyKWh, 0) * 1000 : method === "profile" ? profileTotalEnergyWh : method === "solar_panel_power" ? calculatedPvDailyKWh * 1000 : 0,
      manualPowerW: method === "current" && manualCurrentA ? toNumber(manualCurrentA, 0) * toNumber(manualVoltage || 220, 220) : method === "profile" ? profilePeakPowerW : method === "solar_panel_power" ? totalPanelPowerW : toNumber(manualPowerW, 0),
      manualSurgeW: method === "profile" ? profileSurgePowerW : 0,
      manualHours: toNumber(method === "solar_panel_power" ? psh || 0 : method === "profile" ? 1 : manualHours || 0, 0),
      loadProfile: method === "profile" ? profileLoadProfile : undefined,
    });

    if (method === "profile") {
      localStorage.setItem("shil:profileConsumptionInput", JSON.stringify({
        voltageAC: toNumber(profileVoltage, 220),
        basePowerW: toNumber(profilePowerW, 0),
        startFactor: toNumber(profileStartFactor, 1.6),
        bucketsWh: profileBucketsWh,
        totalEnergyWh: profileTotalEnergyWh,
        peakPowerW: profilePeakPowerW,
        surgePowerW: profileSurgePowerW,
      }));
    }

    localStorage.setItem("shil:loadEngineResult", JSON.stringify(result));
    buildScenarioCalculationInput();
    if (isReadyScenarioEquipmentFlow) {
      localStorage.setItem("shil:scenarioEquipmentConfirmed", "true");
      localStorage.setItem("shil:scenarioNextStep", "system-settings");
      localStorage.setItem("shil:scenarioEquipmentBranch", domain);
    }
    navigate("/new-project/system");
  };

  return (
    <ShilPageShell title={METHOD_LABELS[method] || "ÙˆØ±ÙˆØ¯ÛŒ Ù…Ø­Ø§Ø³Ø¨Ø§Øª"}>
      <ProjectMiniRail />
      <div className="shil-equipment-page">
        <section className="shil-env-card">
          <h3 className="shil-section-title">Ø²Ù…ÛŒÙ†Ù‡ Ù…Ø­Ø§Ø³Ø¨Ø§Øª</h3>
          {isReadyScenarioEquipmentFlow ? (
            <p className="shil-muted-note">{domain === "emergency" ? "Ø³Ù†Ø§Ø±ÛŒÙˆÛŒ Ø¢Ù…Ø§Ø¯Ù‡ Ø¨Ø±Ù‚ Ø§Ø¶Ø·Ø±Ø§Ø±ÛŒ" : "Ø³Ù†Ø§Ø±ÛŒÙˆÛŒ Ø¢Ù…Ø§Ø¯Ù‡ Ø®ÙˆØ±Ø´ÛŒØ¯ÛŒ"} Ø¨Ø¹Ø¯ Ø§Ø² ØªØ£ÛŒÛŒØ¯ Ø´Ø±Ø§ÛŒØ· Ù…Ø­ÛŒØ·ÛŒ ÙˆØ§Ø±Ø¯ Ø§ÛŒÙ† Ù„ÛŒØ³Øª Ø´Ø¯Ù‡ Ø§Ø³Øª. ØªØ¬Ù‡ÛŒØ²Ø§Øª Ù¾ÛŒØ´Ù†Ù‡Ø§Ø¯ÛŒ Ø³Ù†Ø§Ø±ÛŒÙˆ Ø§Ø² Ù‚Ø¨Ù„ Ø§Ù†ØªØ®Ø§Ø¨ Ø´Ø¯Ù‡â€ŒØ§Ù†Ø¯Ø› Ù…ÛŒâ€ŒØªÙˆØ§Ù†ÛŒ Ø­Ø°ÙØŒ Ø§Ø¶Ø§ÙÙ‡ ÛŒØ§ ØªØ¹Ø¯Ø§Ø¯ Ùˆ Ø³Ø§Ø¹Øª Ù…ØµØ±Ù Ø±Ø§ Ø§ØµÙ„Ø§Ø­ Ú©Ù†ÛŒ Ùˆ Ø¨Ø¹Ø¯ Ù…Ø³ÛŒØ± Ø§ØµÙ„ÛŒ Ù¾Ø±ÙˆÚ˜Ù‡ Ø¨Ø§ Ù…ÙˆØªÙˆØ± Ù…Ø­Ø§Ø³Ø¨Ø§ØªÛŒ Ù‡Ù…Ø§Ù† Ø´Ø§Ø®Ù‡ Ø§Ø¯Ø§Ù…Ù‡ Ù¾ÛŒØ¯Ø§ Ù…ÛŒâ€ŒÚ©Ù†Ø¯.</p>
          ) : null}
          <div className="shil-summary-grid">
            <div><span>Ø±ÙˆØ´</span><strong>{METHOD_LABELS[method] || method}</strong></div>
            <div><span>Ù‡Ø³ØªÙ‡</span><strong>{domain === "emergency" ? "Ø¨Ø±Ù‚ Ø§Ø¶Ø·Ø±Ø§Ø±ÛŒ" : "Ø®ÙˆØ±Ø´ÛŒØ¯ÛŒ"}</strong></div>
            <div><span>Ø³Ù†Ø§Ø±ÛŒÙˆ</span><strong>{scenario?.title || "Ø¯Ø³ØªÛŒ"}</strong></div>
            <div><span>Ø´Ù‡Ø±</span><strong>{environment?.city || "Ø§ØµÙÙ‡Ø§Ù†"}</strong></div>
          </div>
        </section>

        {method === "equipment" ? (
          <section className="shil-env-card shil-equipment-picker-card">
            <h3 className="shil-section-title">{isReadyScenarioEquipmentFlow ? (domain === "emergency" ? "Ù„ÛŒØ³Øª ØªØ¬Ù‡ÛŒØ²Ø§Øª Ø³Ù†Ø§Ø±ÛŒÙˆÛŒ Ø¢Ù…Ø§Ø¯Ù‡ Ø¨Ø±Ù‚ Ø§Ø¶Ø·Ø±Ø§Ø±ÛŒ" : "Ù„ÛŒØ³Øª ØªØ¬Ù‡ÛŒØ²Ø§Øª Ø³Ù†Ø§Ø±ÛŒÙˆÛŒ Ø¢Ù…Ø§Ø¯Ù‡ Ø®ÙˆØ±Ø´ÛŒØ¯ÛŒ") : "Ù„ÛŒØ³Øª ØªØ¬Ù‡ÛŒØ²Ø§Øª"}</h3>
            <button type="button" className="shil-equipment-field" onClick={() => setIsEquipmentPickerOpen((v) => !v)}>
              <span>{isReadyScenarioEquipmentFlow ? "Ø§ØµÙ„Ø§Ø­ ØªØ¬Ù‡ÛŒØ²Ø§Øª Ø³Ù†Ø§Ø±ÛŒÙˆÛŒ Ø§Ù†ØªØ®Ø§Ø¨ÛŒ" : "Ø§Ù†ØªØ®Ø§Ø¨ Ø§Ø² Ø¨Ø§Ù†Ú© Û²ÛµÛ° ØªØ¬Ù‡ÛŒØ²"}</span>
              <strong>{selectedItems.length ? `${selectedItems.length} ØªØ¬Ù‡ÛŒØ² Ø§Ù†ØªØ®Ø§Ø¨ Ø´Ø¯Ù‡` : "Ø¨Ø§Ø² Ú©Ø±Ø¯Ù† Ù„ÛŒØ³Øª"}</strong>
            </button>

            {isEquipmentPickerOpen ? (
              <div className="shil-equipment-picker-panel">
                <input
                  className="shil-input"
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Ø¬Ø³ØªØ¬Ùˆ: Ù¾Ù…Ù¾ØŒ Ø±ÙˆØ´Ù†Ø§ÛŒÛŒØŒ Ú©ÙˆÙ„Ø±ØŒ Ø³Ø±ÙˆØ±..."
                />
                <div className="shil-equipment-scroll-list">
                  {items.map((item) => {
                    const selected = selectedIds.has(item.id);
                    const isMotor = item.type === "inductive" || Number(item.surgeFactor || item.startupFactor || 1) > 1.7;
                    return (
                      <button
                        key={item.id}
                        type="button"
                        className={`shil-equipment-option ${selected ? "active" : ""}`}
                        onClick={() => toggleItem(item)}
                      >
                        <strong>{item.title}</strong>
                        <span>{item.ratedPowerW}W Â· {item.usageHoursPerDay}h Â· {isMotor ? "Ù…ÙˆØªÙˆØ±ÛŒ" : "Ù…ØµØ±ÙÛŒ"}</span>
                      </button>
                    );
                  })}
                </div>
                <button type="button" className="shil-secondary-wide" onClick={() => setIsEquipmentPickerOpen(false)}>
                  Ø¨Ø³ØªÙ† Ù„ÛŒØ³Øª ØªØ¬Ù‡ÛŒØ²Ø§Øª
                </button>
              </div>
            ) : null}

            <div className="shil-equipment-actions">
              <button type="button" className="shil-secondary-wide" onClick={applySmartDetails}>
                Ø§Ø¹Ù…Ø§Ù„ Ù‡ÙˆØ´Ù…Ù†Ø¯
              </button>
              <button type="button" className="shil-secondary-wide" onClick={() => setShowExpert((v) => !v)}>
                {showExpert ? "Ø®Ù„Ø§ØµÙ‡ Ø³Ø§Ø¯Ù‡" : "Ù†Ù…Ø§ÛŒØ´ Ø¬Ø²Ø¦ÛŒØ§Øª ØªØ®ØµØµÛŒ"}
              </button>
            </div>

            <p className="shil-muted-note">Ø§Ù†ØªØ®Ø§Ø¨ ØªØ¬Ù‡ÛŒØ²Ø§Øª ÙÙ‚Ø· Ø¯Ø§Ø®Ù„ Ù‡Ù…ÛŒÙ† ÙÛŒÙ„Ø¯ Ø§Ù†Ø¬Ø§Ù… Ù…ÛŒâ€ŒØ´ÙˆØ¯Ø› Ø¨Ø§ Ø¬Ø³ØªØ¬Ùˆ ÛŒØ§ Ø§Ø³Ú©Ø±ÙˆÙ„ Ø§Ù†ØªØ®Ø§Ø¨ Ú©Ù†ØŒ Ø³Ù¾Ø³ Ù„ÛŒØ³Øª Ø±Ø§ Ø¨Ø¨Ù†Ø¯ Ùˆ ØªØ¬Ù‡ÛŒØ²Ø§Øª Ø§Ù†ØªØ®Ø§Ø¨ÛŒ Ø±Ø§ Ø§ØµÙ„Ø§Ø­ Ú©Ù†.</p>
          </section>
        ) : null}

        {method !== "equipment" ? (
          <section className="shil-env-card">
            <h3 className="shil-section-title">Ø§Ø·Ù„Ø§Ø¹Ø§Øª Ù…ÙˆØ±Ø¯ Ù†ÛŒØ§Ø² Ø±Ø§ ÙˆØ§Ø±Ø¯ Ú©Ù†ÛŒØ¯.</h3>
            {method !== "solar_panel_power" ? (
        <section className="shil-env-card">
          <h3 className="shil-section-title">Ø®Ø±ÙˆØ¬ÛŒ Ø²Ù†Ø¯Ù‡ Ù…ÙˆØªÙˆØ± Ø¨Ø§Ø±</h3>
          <div className="shil-summary-grid">
            <div><span>ØªØ¹Ø¯Ø§Ø¯ ØªØ¬Ù‡ÛŒØ²Ø§Øª</span><strong>{enginePreview.selectedCount || "Auto"}</strong></div>
            <div><span>ØªÙˆØ§Ù† Ú©Ù„</span><strong>{enginePreview.totalPowerW} W</strong></div>
            <div><span>Ø§Ù†Ø±Ú˜ÛŒ Ø±ÙˆØ²Ø§Ù†Ù‡</span><strong>{enginePreview.totalEnergyKWh} kWh</strong></div>
            <div><span>Ø¬Ø±ÛŒØ§Ù† AC</span><strong>{enginePreview.acCurrentA} A</strong></div>
            <div><span>Ø¬Ø±ÛŒØ§Ù† Ø±Ø§Ù‡â€ŒØ§Ù†Ø¯Ø§Ø²ÛŒ</span><strong>{enginePreview.startCurrentA} A</strong></div>
            <div><span>Ù¾ÛŒÚ© Ø§Ø³ØªØ§Ø±Øª</span><strong>{enginePreview.surgePowerW} W</strong></div>
            <div><span>Ù…ÙˆØªÙˆØ±ÛŒ/Ø³Ø§ÙØª</span><strong>{enginePreview.motorCount || 0}/{enginePreview.softStarterCount || 0}</strong></div>
          </div>
          {showExpert ? (
            <div className="shil-expert-box">
              <strong>Ù…Ù†Ø·Ù‚ Ù¾Ø´Øª Ù¾Ø±Ø¯Ù‡:</strong>
              <p>{enginePreview.expertSummary?.rule}</p>
              <p>{enginePreview.expertSummary?.motorStartRule}</p>
            </div>
          ) : null}
          {enginePreview.warnings?.length ? (
            <ul className="shil-warning-list">
              {enginePreview.warnings.map((warning) => <li key={warning}>{warning}</li>)}
            </ul>
          ) : null}
        </section>
        ) : null}

        {method === "profile" ? (
              <>
                <div className="shil-form-grid">
                  <label>ØªÙˆØ§Ù† Ù‡Ù…Ø²Ù…Ø§Ù†/Ù¾ÛŒÚ© Ù…ØµØ±Ù W<input className="shil-input" value={profilePowerW} onChange={(e) => setProfilePowerW(e.target.value)} placeholder="Ù…Ø«Ù„Ø§Ù‹ 3500" inputMode="numeric" /></label>
                  <label>ÙˆÙ„ØªØ§Ú˜ AC<select className="shil-input" value={profileVoltage} onChange={(e) => setProfileVoltage(e.target.value)}><option value="220">Û²Û²Û° ÙˆÙ„Øª ØªÚ©â€ŒÙØ§Ø²</option><option value="380">Û³Û¸Û° ÙˆÙ„Øª Ø³Ù‡â€ŒÙØ§Ø²</option></select></label>
                  <label>Ø¶Ø±ÛŒØ¨ Ø±Ø§Ù‡â€ŒØ§Ù†Ø¯Ø§Ø²ÛŒ/Ù¾ÛŒÚ©<input className="shil-input" value={profileStartFactor} onChange={(e) => setProfileStartFactor(e.target.value)} placeholder="Ù…Ø«Ù„Ø§Ù‹ 1.6" inputMode="decimal" /></label>
                  <label>Ù…ØµØ±Ù ØµØ¨Ø­ kWh<input className="shil-input" value={profileMorningKWh} onChange={(e) => setProfileMorningKWh(e.target.value)} inputMode="decimal" /></label>
                  <label>Ù…ØµØ±Ù Ø¸Ù‡Ø± kWh<input className="shil-input" value={profileNoonKWh} onChange={(e) => setProfileNoonKWh(e.target.value)} inputMode="decimal" /></label>
                  <label>Ù…ØµØ±Ù Ø¹ØµØ± kWh<input className="shil-input" value={profileEveningKWh} onChange={(e) => setProfileEveningKWh(e.target.value)} inputMode="decimal" /></label>
                  <label>Ù…ØµØ±Ù Ø´Ø¨ kWh<input className="shil-input" value={profileNightKWh} onChange={(e) => setProfileNightKWh(e.target.value)} inputMode="decimal" /></label>
                </div>
                <div className="shil-summary-grid">
                  <div><span>Ù…ØµØ±Ù Ú©Ù„ Ø±ÙˆØ²Ø§Ù†Ù‡</span><strong>{(profileTotalEnergyWh / 1000).toFixed(2)} kWh</strong></div>
                  <div><span>ØªÙˆØ§Ù† Ù¾ÛŒÚ© Ù…Ø¨Ù†Ø§</span><strong>{Math.round(profilePeakPowerW)} W</strong></div>
                  <div><span>ØªÙˆØ§Ù† Ø±Ø§Ù‡â€ŒØ§Ù†Ø¯Ø§Ø²ÛŒ</span><strong>{profileSurgePowerW} W</strong></div>
                  <div><span>Ø¨Ø§Ø²Ù‡ Ù¾ÛŒÚ© Ù…ØµØ±Ù</span><strong>{profileLoadProfile.peakBucket === "night" ? "Ø´Ø¨" : profileLoadProfile.peakBucket === "noon" ? "Ø¸Ù‡Ø±" : profileLoadProfile.peakBucket === "morning" ? "ØµØ¨Ø­" : "Ø¹ØµØ±"}</strong></div>
                </div>
                <p className="shil-muted-note">Ø§ÛŒÙ† Ù…Ø³ÛŒØ± ÙÙ‚Ø· Ø¨Ø± Ø§Ø³Ø§Ø³ Ø§Ù„Ú¯ÙˆÛŒ Ù…ØµØ±Ù Ø±ÙˆØ²Ø§Ù†Ù‡ Ú©Ø§Ø± Ù…ÛŒâ€ŒÚ©Ù†Ø¯ Ùˆ Ø¨Ø§Ù†Ú© Ù¾Ù†Ù„ØŒ MPPT Ùˆ ØªÙ‚Ø³ÛŒÙ… Ù¾Ù†Ù„ Ø¯Ø± Ø¢Ù† Ù†Ù…Ø§ÛŒØ´ Ø¯Ø§Ø¯Ù‡ Ù†Ù…ÛŒâ€ŒØ´ÙˆØ¯.</p>
              </>
            ) : method === "solar_panel_power" ? (
              <>
                <div className="shil-form-grid">
                  <label>Ø¨Ø§Ù†Ú© Ú©Ø§Ù…Ù„ Ù¾Ù†Ù„ Ø®ÙˆØ±Ø´ÛŒØ¯ÛŒ<select className="shil-input" value={selectedPanelId} onChange={(e) => setSelectedPanelId(e.target.value)}>{SHIL_SOLAR_PANELS.map((panel) => <option key={panel.id} value={panel.id}>{panel.title} / {panel.powerW}W / {panel.type}</option>)}</select></label>
                  <label>ØªÙˆØ§Ù† Ù‡Ø± Ù¾Ù†Ù„ W<input className="shil-input" value={panelPowerW} readOnly /></label>
                  <label>ØªØ¹Ø¯Ø§Ø¯ Ù¾Ù†Ù„<input className="shil-input" value={panelCount} onChange={(e) => setPanelCount(e.target.value)} placeholder="Ù…Ø«Ù„Ø§Ù‹ 24" inputMode="numeric" /></label>
                  <label>Ø³Ø§Ø¹Ø§Øª Ø¢ÙØªØ§Ø¨ Ù…Ø¤Ø«Ø± PSH<input className="shil-input" value={psh} onChange={(e) => setPsh(e.target.value)} placeholder={`Ø§Ø² Ø´Ø±Ø§ÛŒØ· Ù…Ø­ÛŒØ·ÛŒ: ${envSolarDefaults.psh}`} inputMode="decimal" /></label>
                  <label>ØªÙ„ÙØ§Øª Ú©Ù„ Ø³ÛŒØ³ØªÙ… Ùª<input className="shil-input" value={lossPercent} onChange={(e) => setLossPercent(e.target.value)} placeholder={`Ø§Ø² Ø´Ø±Ø§ÛŒØ· Ù…Ø­ÛŒØ·ÛŒ: ${envSolarDefaults.totalLoss}%`} inputMode="decimal" /></label>
                  <label>Ø±Ø§Ù†Ø¯Ù…Ø§Ù† Ù…Ø¤Ø«Ø± Ø³ÛŒØ³ØªÙ… Ùª<input className="shil-input" value={(100 - toNumber(lossPercent, 0)).toFixed(1)} onChange={(e) => { const efficiency = Math.max(5, Math.min(100, toNumber(e.target.value, 0))); setLossPercent(String((100 - efficiency).toFixed(1))); }} placeholder="Ù…Ø­Ø§Ø³Ø¨Ù‡ Ø§Ø² Ø´Ø±Ø§ÛŒØ· Ù…Ø­ÛŒØ·ÛŒ" inputMode="decimal" /></label>
                  <label>Ù…Ø³ÛŒØ± Ø®Ø±ÙˆØ¬ÛŒ AC<select className="shil-input" value={acVoltageRoute} onChange={(e) => setAcVoltageRoute(e.target.value)}><option value="220">Û²Û²Û° ÙˆÙ„Øª ØªÚ©â€ŒÙØ§Ø²</option><option value="380">Û³Û¸Û° ÙˆÙ„Øª Ø³Ù‡â€ŒÙØ§Ø²</option></select></label>
                </div>
                <div className="shil-summary-grid"><div><span>ØªÙˆØ§Ù† Ú©Ù„ Ù¾Ù†Ù„â€ŒÙ‡Ø§</span><strong>{(totalPanelPowerW / 1000).toFixed(2)} kW</strong></div><div><span>ØªÙˆÙ„ÛŒØ¯ Ø±ÙˆØ²Ø§Ù†Ù‡ Ø¨Ø¯ÙˆÙ† ØªÙ„ÙØ§Øª</span><strong>{rawPvDailyKWh} kWh</strong></div><div><span>ØªÙˆÙ„ÛŒØ¯ Ø±ÙˆØ²Ø§Ù†Ù‡ Ø¨Ø§ ØªÙ„ÙØ§Øª</span><strong>{calculatedPvDailyKWh} kWh</strong></div><div><span>ØªÙˆØ§Ù† Ù…ÙˆØ«Ø± Ù…Ø¹ÛŒØ§Ø± Ù…Ø³ÛŒØ±</span><strong>{(effectivePanelPowerW / 1000).toFixed(2)} kW</strong></div><div><span>Ù…Ø­Ø¯ÙˆØ¯Ù‡ Ø·Ø±Ø§Ø­ÛŒ</span><strong>{isUtilityPanelScale ? "Ù†ÛŒØ±ÙˆÚ¯Ø§Ù‡ÛŒ / ØªÙˆØ§Ù† Ù…ÙˆØ«Ø± Ø¨Ø§Ù„Ø§ÛŒ Û³Û°kW" : "Ù…ØµØ±ÙÛŒ Ø¹Ø§Ø¯ÛŒ / ØªÙˆØ§Ù† Ù…ÙˆØ«Ø± Ø²ÛŒØ± Û³Û°kW"}</strong></div><div><span>Ù…Ù†Ø¨Ø¹ PSH Ùˆ ØªÙ„ÙØ§Øª</span><strong>{environment?.city || "Ø´Ø±Ø§ÛŒØ· Ù…Ø­ÛŒØ·ÛŒ"}</strong></div><div><span>Ø±Ø§Ù†Ø¯Ù…Ø§Ù† Ù…Ø¤Ø«Ø±</span><strong>{(100 - toNumber(lossPercent, 0)).toFixed(1)}Ùª</strong></div><div><span>Ø§ÙØª Ø¬Ù‡Øª/Ø²Ø§ÙˆÛŒÙ‡</span><strong>{envSolarDefaults.orientation.toFixed(1)}Ùª</strong></div></div>
                {isUtilityPanelScale && !isUtilityGateway ? (<div className="shil-inline-warning"><strong>ØªÙˆØ§Ù† Ù…ÙˆØ«Ø± Ø¨Ø§Ù„Ø§ÛŒ Û³Û°kW Ø§Ø³Øª.</strong><button type="button" className="shil-secondary-wide" onClick={goToUtilityGateway}>ÙˆØ±ÙˆØ¯ Ø¨Ù‡ Ø¯Ø±Ú¯Ø§Ù‡ Ù†ÛŒØ±ÙˆÚ¯Ø§Ù‡ÛŒ</button></div>) : null}
              </>
            ) : (
              <div className="shil-form-grid">
                {method === "energy" ? <label>Ø§Ù†Ø±Ú˜ÛŒ Ø±ÙˆØ²Ø§Ù†Ù‡ kWh<input className="shil-input" value={manualEnergyKWh} onChange={(e) => setManualEnergyKWh(e.target.value)} placeholder="Ù…Ø«Ù„Ø§Ù‹ 12.5" inputMode="decimal" /></label> : null}
                {method === "power" ? <label>ØªÙˆØ§Ù† Ú©Ù„ W<input className="shil-input" value={manualPowerW} onChange={(e) => setManualPowerW(e.target.value)} placeholder="Ù…Ø«Ù„Ø§Ù‹ 3500" inputMode="numeric" /></label> : null}
                {method === "current" ? <label>Ø¬Ø±ÛŒØ§Ù† Ú©Ù„ A<input className="shil-input" value={manualCurrentA} onChange={(e) => setManualCurrentA(e.target.value)} placeholder="Ù…Ø«Ù„Ø§Ù‹ 16" inputMode="decimal" /></label> : null}
                <label>ÙˆÙ„ØªØ§Ú˜ AC<input className="shil-input" value={manualVoltage} onChange={(e) => setManualVoltage(e.target.value)} inputMode="numeric" /></label>
                <label>Ø³Ø§Ø¹Øª Ø§Ø³ØªÙØ§Ø¯Ù‡ / Ø²Ù…Ø§Ù† Ø¨Ø±Ù‚ Ø§Ø¶Ø·Ø±Ø§Ø±ÛŒ Ù…ÙˆØ±Ø¯ Ù†Ø¸Ø±<input className="shil-input" value={manualHours} onChange={(e) => setManualHours(e.target.value)} inputMode="decimal" /></label>
              </div>
            )}
          </section>
        ) : null}

        {method === "profile" ? (
          <section className="shil-env-card">
            <h3 className="shil-section-title">Ù¾Ø±ÙˆÙØ§ÛŒÙ„ Ù…ØµØ±Ù ØªØ®Ù…ÛŒÙ†ÛŒ</h3>
            <div className="shil-summary-grid">
              <div><span>ØµØ¨Ø­</span><strong>{Math.round(enginePreview.loadProfile.buckets.morning / 1000)} kWh</strong></div>
              <div><span>Ø¸Ù‡Ø±</span><strong>{Math.round(enginePreview.loadProfile.buckets.noon / 1000)} kWh</strong></div>
              <div><span>Ø¹ØµØ±</span><strong>{Math.round(enginePreview.loadProfile.buckets.evening / 1000)} kWh</strong></div>
              <div><span>Ø´Ø¨</span><strong>{Math.round(enginePreview.loadProfile.buckets.night / 1000)} kWh</strong></div>
            </div>
          </section>
        ) : null}

        {method === "equipment" ? (
          <section className="shil-selected-equipment-list">
            <h3 className="shil-section-title">ØªØ¬Ù‡ÛŒØ²Ø§Øª Ø§Ù†ØªØ®Ø§Ø¨ÛŒ</h3>
            {!selectedItems.length ? (
              <div className="shil-empty-selection">Ù‡Ù†ÙˆØ² ØªØ¬Ù‡ÛŒØ²ÛŒ Ø§Ù†ØªØ®Ø§Ø¨ Ù†Ø´Ø¯Ù‡ Ø§Ø³Øª.</div>
            ) : selectedItems.map((item) => {
              const override = itemOverrides[item.id] || {};
              const preview = enginePreview.selectedItems?.find((x) => x.id === item.id);
              const isMotor = item.type === "inductive" || Number(item.surgeFactor || item.startupFactor || 1) > 1.7;
              return (
                <article key={item.id} className="shil-equipment-card active">
                  <div className="shil-selected-equipment-head">
                    <div>
                      <strong>{item.title}</strong>
                      <span>{item.category} | {isMotor ? "Ù…ÙˆØªÙˆØ±ÛŒ" : "Ù…Ù‚Ø§ÙˆÙ…ØªÛŒ/Ø§Ù„Ú©ØªØ±ÙˆÙ†ÛŒÚ©ÛŒ"}{override.scenarioSeeded ? " | Ù¾ÛŒØ´Ù†Ù‡Ø§Ø¯ Ø³Ù†Ø§Ø±ÛŒÙˆ" : ""}</span>
                    </div>
                    <button type="button" className="shil-remove-equipment" onClick={() => toggleItem(item)}>Ø­Ø°Ù</button>
                  </div>
                  <div className="shil-equipment-controls">
                    <label>ØªØ¹Ø¯Ø§Ø¯<input className="shil-input" value={override.quantity ?? item.quantity ?? 1} onChange={(e) => patchOverride(item.id, { quantity: e.target.value })} inputMode="numeric" /></label>
                    <label>Ø³Ø§Ø¹Øª Ù…ØµØ±Ù<input className="shil-input" value={override.usageHoursPerDay ?? item.usageHoursPerDay} onChange={(e) => patchOverride(item.id, { usageHoursPerDay: e.target.value })} inputMode="decimal" /></label>
                    {showExpert ? (
                      <>
                        <label>Ø¶Ø±ÛŒØ¨ Ù‡Ù…Ø²Ù…Ø§Ù†ÛŒ<input className="shil-input" value={override.simultaneityFactor ?? item.simultaneityFactor ?? item.diversityFactor ?? 1} onChange={(e) => patchOverride(item.id, { simultaneityFactor: e.target.value })} inputMode="decimal" /></label>
                        <label>Ø±Ø§Ù†Ø¯Ù…Ø§Ù†/PF<input className="shil-input" value={override.powerFactor ?? item.powerFactor ?? 0.95} onChange={(e) => patchOverride(item.id, { powerFactor: e.target.value })} inputMode="decimal" /></label>
                      </>
                    ) : null}
                    {isMotor ? (
                      <label className="shil-check-row">
                        <input type="checkbox" checked={Boolean(override.hasSoftStarter)} onChange={(e) => patchOverride(item.id, { hasSoftStarter: e.target.checked })} />
                        Ø³Ø§ÙØªâ€ŒØ§Ø³ØªØ§Ø±ØªØ± Ø¯Ø§Ø±Ø¯Ø› Ø¬Ø±ÛŒØ§Ù† Ø±Ø§Ù‡â€ŒØ§Ù†Ø¯Ø§Ø²ÛŒ Ø§Ø² Û².ÛµÃ— Ø¨Ù‡ Û±.Û²Ã— Ø¬Ø±ÛŒØ§Ù† Ù†Ø§Ù…ÛŒ Ú©Ø§Ù‡Ø´ ÛŒØ§Ø¨Ø¯
                      </label>
                    ) : showExpert ? (
                      <div className="shil-load-kind-note">Ù†ÙˆØ¹ Ø¨Ø§Ø±: Ù…Ù‚Ø§ÙˆÙ…ØªÛŒ/Ø§Ù„Ú©ØªØ±ÙˆÙ†ÛŒÚ©ÛŒ</div>
                    ) : null}
                    {showExpert && preview ? (
                      <div className="shil-expert-mini">
                        <span>Ø¬Ø±ÛŒØ§Ù† Ù†Ø§Ù…ÛŒ: {preview.nominalCurrentA} A</span>
                        <span>Ø¬Ø±ÛŒØ§Ù† Ú©Ø§Ø±Ú©Ø±Ø¯: {preview.runningCurrentA} A</span>
                        <span>Ø¬Ø±ÛŒØ§Ù† Ø±Ø§Ù‡â€ŒØ§Ù†Ø¯Ø§Ø²ÛŒ: {preview.startCurrentA} A</span>
                        <span>Ø¶Ø±ÛŒØ¨ Ø§Ø³ØªØ§Ø±Øª: Ã—{preview.currentStartFactor}</span>
                        <small>{preview.expertReason}</small>
                      </div>
                    ) : null}
                  </div>
                </article>
              );
            })}
          </section>
        ) : null}

        {scaleWarning ? <div className="shil-inline-warning">{scaleWarning}<button type="button" className="shil-secondary-wide" onClick={goToUtilityGateway}>ÙˆØ±ÙˆØ¯ Ø¨Ù‡ Ø¯Ø±Ú¯Ø§Ù‡ Ù†ÛŒØ±ÙˆÚ¯Ø§Ù‡ÛŒ</button></div> : null}
        <button type="button" className="shil-primary-wide" onClick={confirmLoad}>
          {isReadyScenarioEquipmentFlow ? "ØªØ£ÛŒÛŒØ¯ Ù„ÛŒØ³Øª ØªØ¬Ù‡ÛŒØ²Ø§Øª Ùˆ Ø§Ø¯Ø§Ù…Ù‡ Ù…Ø³ÛŒØ± Ù¾Ø±ÙˆÚ˜Ù‡" : "ØªØ£ÛŒÛŒØ¯ Ø§Ø·Ù„Ø§Ø¹Ø§Øª Ùˆ ÙˆØ±ÙˆØ¯ Ø¨Ù‡ Ù¾ÛŒÚ©Ø±Ø¨Ù†Ø¯ÛŒ ØªÙ†Ø¸ÛŒÙ…Ø§Øª"}
        </button>
      </div>
    </ShilPageShell>
  );
}
