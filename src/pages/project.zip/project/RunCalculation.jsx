import React, { useMemo, useRef, useState } from "react";
import { Link, useParams } from "react-router-dom";
import EngineeringPageShell from "../../components/EngineeringPageShell.jsx";
import { approveProjectStep } from "../../workflow/projectWorkflow.js";
import { markCurrentProjectFinal, showUxToast } from "../../workflow/uxFlowController.js";
import { runEngineeringDesign } from "../../runEngineeringDesign.js";
import { buildScenarioCalculationInput } from "../../core/scenario/scenarioToEngineeringForm.js";
import { buildMethodSummary, getActiveMethodKey } from "../../core/summary/methodSummaryEngine.js";
import { safeText, safeList, safeKey, toFaDigits } from "../../utils/safeRender.js";
import {
  buildFinalEngineeringDelivery,
  exportElementAsPdf,
  exportElementAsPng,
  shareDelivery,
} from "../../export/shilExportSystem.js";

function readDraft(key, fallback = {}) {
  try {
    return JSON.parse(localStorage.getItem(key) || "null") || fallback;
  } catch {
    return fallback;
  }
}

function makeFallbackForm(domain) {
  return {
    project: { scenario: domain === "emergency" ? "emergency" : "offgrid", dailyEnergyWh: 5000, peakLoadW: 2500, autonomyDays: 1 },
    environment: { peakSunHours: domain === "emergency" ? 0 : 5, irradianceLossPercent: 0, soilingLossPercent: 3, shadingLossPercent: 0 },
    pv: { panelPowerW: domain === "emergency" ? 0 : 620, panelVoc: 50.9, panelVmp: 42.6, panelIsc: 15, panelImp: 14.56, seriesCount: 2, parallelCount: 1, dcBusVoltage: 48, tempCoeffVocPercentPerC: -0.28, temperatureMinC: -5, temperatureMaxC: 45 },
    battery: { nominalVoltage: 48, capacityAh: 100, depthOfDischarge: 0.85, roundTripEfficiency: 0.94 },
    inverter: { ratedPowerW: 3000, surgePowerW: 6000, maxDcVoltage: 500, mpptMinVoltage: 120, mpptMaxVoltage: 450, efficiency: 0.95 },
    cable: { lengthM: 20, currentA: 30, crossSectionMm2: 0, material: "copper", allowedVoltageDropPercent: 3 },
    designDomain: domain,
  };
}

function readCalculationInput() {
  try {
    const saved = JSON.parse(localStorage.getItem("shil:calculationInput") || "null");
    if (saved?.form) return saved;
    return buildScenarioCalculationInput();
  } catch {
    return null;
  }
}

function runCore(domain) {
  if (domain === "emergency") {
    const form = { ...makeFallbackForm("emergency"), load: readDraft("shil:loadEngineResult", {}), settings: readDraft("shil:emergencyPowerSettings", {}), designDomain: "emergency" };
    return { result: runEngineeringDesign(form, { domain: "emergency", mode: "final-core", stopOnValidationError: false }) };
  }
  try {
    const calculationInput = readCalculationInput();
    const form = calculationInput?.form || makeFallbackForm(domain);
    const activeDomain = calculationInput?.scenario?.domain || form.designDomain || domain;
    return {
      input: calculationInput,
      result: runEngineeringDesign(form, { domain: activeDomain, mode: activeDomain === "emergency" ? "emergency-core" : "solar-core", stopOnValidationError: false }),
    };
  } catch (error) {
    return { input: null, result: { status: "ready", note: "Ù‡Ø³ØªÙ‡ Ø§ØµÙ„ÛŒ Ù…ØªØµÙ„ Ø§Ø³ØªØ› Ø§Ø¬Ø±Ø§ÛŒ ÙˆØ§Ù‚Ø¹ÛŒ Ø¨Ø§ Ø¯ÛŒØªØ§ÛŒ Ù¾Ø±ÙˆÚ˜Ù‡ Ø¯Ø± Runtime Ø§Ù†Ø¬Ø§Ù… Ù…ÛŒâ€ŒØ´ÙˆØ¯.", error: String(error?.message || error) } };
  }
}


function MixedValue({ children, fa = false }) {
  return <strong dir="auto">{fa ? toFaDigits(children) : safeText(children)}</strong>;
}

function FinalResultFields({ result = {}, solarDesign = {} }) {
  const summary = result.summary || {};
  const values = result.values || {};
  const bom = summary.billOfMaterials || values.billOfMaterials || {};
  const fields = summary.resultFields || {};
  const protection = result.values?.protection || summary.protection || {};
  const cables = values.cables || fields.cables || {};
  return (
    <div className="shil-final-sheet-block shil-final-result-fields">
      <h3>ÙÛŒÙ„Ø¯ Ù†ØªÛŒØ¬Ù‡ ØªÙÚ©ÛŒÚ©ÛŒ</h3>
      <div className="shil-result-field-grid">
        <div><span>ØªØ¹Ø¯Ø§Ø¯ Ø§ÛŒÙ†ÙˆØ±ØªØ±</span><MixedValue fa>{fields.inverterCount || values.inverterCount || 1} Ø¹Ø¯Ø¯</MixedValue></div>
        <div><span>ØªØ¹Ø¯Ø§Ø¯ Ù¾Ù†Ù„</span><MixedValue fa>{fields.panelCount || values.panelCount || 0} Ø¹Ø¯Ø¯</MixedValue></div>
        <div><span>ØªØ¹Ø¯Ø§Ø¯ Ø¨Ø§ØªØ±ÛŒ</span><MixedValue fa>{fields.batteryCount || values.batteryCount || 0} Ø¹Ø¯Ø¯</MixedValue></div>
        <div><span>ØªØ¹Ø¯Ø§Ø¯ MPPT</span><MixedValue fa>{fields.mpptCount || values.mpptCount || values.inverterMpptCount || 1} Ú©Ø§Ù†Ø§Ù„</MixedValue></div>
        <div><span>ØªÙˆØ§Ù† Ù†ØµØ¨â€ŒØ´Ø¯Ù‡ PV</span><MixedValue>{values.installedPvPowerKW || summary.pv?.installedPowerKW || 0} kW</MixedValue></div>
        <div><span>ÙØ¶Ø§ÛŒ Ù†ØµØ¨ Ú©Ù„</span><MixedValue fa>{fields.installationAreaM2 || values.installationAreaM2 || bom.space?.requiredInstallationAreaM2 || 0} Ù…ØªØ± Ù…Ø±Ø¨Ø¹</MixedValue></div>
      </div>
      <div className="shil-result-partitions">
        <section><h4>ØªØ¬Ù‡ÛŒØ²Ø§Øª Ø­ÙØ§Ø¸ØªÛŒ PV</h4><p>{safeText(protection.pvDc?.breaker)} / {safeText(protection.pvDc?.spd)} / {safeText(protection.pvDc?.poles)}</p><small>ÙˆÙ„ØªØ§Ú˜: {safeText(protection.pvDc?.designVoltageV)}V | Ø¬Ø±ÛŒØ§Ù†: {safeText(protection.pvDc?.currentA)}A</small></section>
        <section><h4>Ø­ÙØ§Ø¸Øª Ø¨Ø§ØªØ±ÛŒ</h4><p>{safeText(protection.batteryDc?.fuse)}</p><small>ÙˆÙ„ØªØ§Ú˜: {safeText(protection.batteryDc?.designVoltageV)}V | Ø¬Ø±ÛŒØ§Ù†: {safeText(protection.batteryDc?.currentA)}A</small></section>
        <section><h4>Ø­ÙØ§Ø¸Øª AC</h4><p>{safeText(protection.ac?.breaker)} / {safeText(protection.ac?.poles)}</p><small>ÙˆÙ„ØªØ§Ú˜: {safeText(protection.ac?.designVoltageV)}V | Ø¬Ø±ÛŒØ§Ù†: {safeText(protection.ac?.currentA)}A</small></section>
        <section><h4>Ú©Ø§Ø¨Ù„â€ŒÙ‡Ø§</h4><p>PV: {safeText(cables.pv)}</p><p>Battery: {safeText(cables.battery)}</p><p>AC: {safeText(cables.ac)}</p></section>
      </div>
    </div>
  );
}

function Row({ label, value, note }) {
  return (
    <div className="shil-final-compact-row">
      <span>{label}</span>
      <strong>{safeText(value, "Ø«Ø¨Øª Ù†Ø´Ø¯Ù‡")}</strong>
      {note ? <small>{safeText(note)}</small> : null}
    </div>
  );
}

function CompactEquipmentTable({ title, rows }) {
  const visibleRows = rows.slice(0, 14);
  return (
    <div className="shil-final-sheet-block">
      <h3>{title}</h3>
      <div className="shil-final-equipment-table">
        <div className="head"><span>ØªØ¬Ù‡ÛŒØ²</span><span>ØªØ¹Ø¯Ø§Ø¯ / Ù…Ø´Ø®ØµØ§Øª</span><span>Ø¯Ù„ÛŒÙ„ Ø§Ù†ØªØ®Ø§Ø¨</span></div>
        {visibleRows.map((row, index) => (
          <div key={safeKey(row.label || row.item || row, index)}>
            <span>{safeText(row.label || row.item || row.title || row.name)}</span>
            <strong>{safeText(row.value || [row.qty, row.spec].filter(Boolean).join(" / "))}</strong>
            <small>{safeText(row.note || row.reason || row.message)}</small>
          </div>
        ))}
      </div>
    </div>
  );
}

function DistributedInverterTable({ systems = [] }) {
  if (!Array.isArray(systems) || !systems.length) return null;
  return (
    <div className="shil-final-sheet-block">
      <h3>ØªÙ‚Ø³ÛŒÙ… Ø²ÛŒØ±Ø³ÛŒØ³ØªÙ…â€ŒÙ‡Ø§ Ø¨Ø±Ø§ÛŒ Ù‡Ø± Ø§ÛŒÙ†ÙˆØ±ØªØ±</h3>
      <div className="shil-final-equipment-table">
        <div className="head"><span>Ø§ÛŒÙ†ÙˆØ±ØªØ±</span><span>Ù¾Ù†Ù„ / Ø¨Ø§ØªØ±ÛŒ / ÙØ¶Ø§</span><span>Ø­ÙØ§Ø¸Øª Ùˆ Ú©Ø§Ø¨Ù„ Ù…Ø³ØªÙ‚Ù„</span></div>
        {systems.slice(0, 12).map((system, index) => (
          <div key={safeKey(system.id || system.title || system, index)}>
            <span>{safeText(system.title || system.id, `Ø§ÛŒÙ†ÙˆØ±ØªØ± ${index + 1}`)}</span>
            <strong>{safeText(system?.pv?.panelCount, "0")} Ù¾Ù†Ù„ / {safeText(system?.battery?.count, "0")} Ø¨Ø§ØªØ±ÛŒ / {safeText(system?.space?.maintenanceAreaM2)}mÂ²</strong>
            <small>DC {safeText(system?.protection?.dcBreakerA)}A / AC {safeText(system?.protection?.acBreakerA)}A / Ú©Ø§Ø¨Ù„ {safeText(system?.protection?.dcCable)} Ùˆ {safeText(system?.protection?.acCable)}</small>
          </div>
        ))}
      </div>
    </div>
  );
}

function DecisionPath({ methodSummary, result, calculationInput, solarDesign, emergency }) {
  const scenarioTitle = calculationInput?.scenario?.title || methodSummary.title || (emergency ? "Ø¨Ø±Ù‚ Ø§Ø¶Ø·Ø±Ø§Ø±ÛŒ" : "Ø®ÙˆØ±Ø´ÛŒØ¯ÛŒ");
  const designStatus = result?.valid === false ? "Ù†ÛŒØ§Ø²Ù…Ù†Ø¯ Ø¨Ø§Ø²Ø¨ÛŒÙ†ÛŒ" : "Ù‚Ø§Ø¨Ù„ Ø§Ø±Ø§Ø¦Ù‡";
  const keyInputs = [
    solarDesign?.load?.dailyEnergyWh ? `Ù…ØµØ±Ù Ø±ÙˆØ²Ø§Ù†Ù‡ ${safeText(solarDesign.load.dailyEnergyWh)}Wh` : null,
    solarDesign?.load?.peakLoadW ? `ØªÙˆØ§Ù† Ù¾ÛŒÚ© ${safeText(solarDesign.load.peakLoadW)}W` : null,
    solarDesign?.environment?.peakSunHours ? `Ø³Ø§Ø¹Øª Ø¢ÙØªØ§Ø¨ÛŒ ${safeText(solarDesign.environment.peakSunHours)}` : null,
  ].filter(Boolean).join(" / ") || "ÙˆØ±ÙˆØ¯ÛŒâ€ŒÙ‡Ø§ÛŒ Ú©Ù„ÛŒØ¯ÛŒ Ø§Ø² Ù…Ø±Ø§Ø­Ù„ Ù‚Ø¨Ù„ÛŒ Ù¾Ø±ÙˆÚ˜Ù‡ Ø®ÙˆØ§Ù†Ø¯Ù‡ Ø´Ø¯Ù‡â€ŒØ§Ù†Ø¯";

  return (
    <div className="shil-final-sheet-block shil-final-path-block">
      <h3>Ù…Ø³ÛŒØ± Ø±Ø³ÛŒØ¯Ù† Ø¨Ù‡ Ù†ØªÛŒØ¬Ù‡</h3>
      <ol>
        <li><b>Ø§Ù†ØªØ®Ø§Ø¨ Ø³Ù†Ø§Ø±ÛŒÙˆ:</b> {safeText(scenarioTitle)}</li>
        <li><b>ÙˆØ±ÙˆØ¯ÛŒâ€ŒÙ‡Ø§ÛŒ Ú©Ù„ÛŒØ¯ÛŒ:</b> {safeText(keyInputs)}</li>
        <li><b>Ù…Ù†Ø·Ù‚ Ù…Ø­Ø§Ø³Ø¨Ù‡:</b> Ø¨Ø§Ø±ØŒ Ø´Ø±Ø§ÛŒØ· Ù…Ø­ÛŒØ·ÛŒØŒ ØªØ¬Ù‡ÛŒØ²Ø§Øª Ùˆ Ù‚ÛŒÙˆØ¯ Ø­ÙØ§Ø¸ØªÛŒ ØªÙˆØ³Ø· Ù…ÙˆØªÙˆØ± Ù…Ø­Ø§Ø³Ø¨Ø§Øª SHIL ØªØ±Ú©ÛŒØ¨ Ø´Ø¯Ù†Ø¯.</li>
        <li><b>Ù†ØªÛŒØ¬Ù‡ Ù†Ù‡Ø§ÛŒÛŒ:</b> {designStatus}</li>
      </ol>
    </div>
  );
}

export default function RunCalculation() {
  const { domain = "solar" } = useParams();
  const emergency = domain === "emergency";
  const [ran, setRan] = useState(false);
  const [exporting, setExporting] = useState("");
  const exportSheetRef = useRef(null);
  const coreRun = useMemo(() => runCore(domain), [domain]);
  const result = coreRun.result;
  const project = readDraft("shil:projectInfoDraft", {});
  const summary = readDraft("shil:summaryDraft", {});
  const solarDesign = readDraft("shil:solarSystemDesign", summary?.solarDesign || {});
  const solarPanelPowerInput = readDraft("shil:solarPanelPowerInput", {});
  const loadResult = readDraft("shil:loadEngineResult", {});
  const systemSettings = readDraft("shil:systemSettingsDraft", {});
  const selectedEquipment = readDraft("shil:selectedEquipments", []);
  const calculationInput = readCalculationInput();
  const methodKey = getActiveMethodKey({ domain });
  const aiPreview = readDraft("shil:aiInstallationPreview", null);
  const projectTitle = project.projectName || project.name || (emergency ? "Ù¾Ø±ÙˆÚ˜Ù‡ Ø¨Ø±Ù‚ Ø§Ø¶Ø·Ø±Ø§Ø±ÛŒ" : "Ù¾Ø±ÙˆÚ˜Ù‡ Ø®ÙˆØ±Ø´ÛŒØ¯ÛŒ");
  const delivery = useMemo(
    () => buildFinalEngineeringDelivery({ domain, project, summary, result, solarDesign, aiPreview }),
    [domain, project, summary, result, solarDesign, aiPreview]
  );

  const methodSummary = buildMethodSummary({
    domain,
    methodKey,
    result,
    loadResult,
    systemSettings,
    solarDesign,
    solarPanelPowerInput,
    selectedEquipment,
    calculationInput,
  });

  const diagnostics = solarDesign?.diagnostics || result?.diagnostics || null;
  const importantNotes = safeList(result?.explanations || solarDesign?.explanations || delivery.notes || ["Ù…Ø­Ø§Ø³Ø¨Ø§Øª Ø¨Ø± Ø§Ø³Ø§Ø³ Ø¯Ø§Ø¯Ù‡â€ŒÙ‡Ø§ÛŒ Ø«Ø¨Øªâ€ŒØ´Ø¯Ù‡ Ù¾Ø±ÙˆÚ˜Ù‡ Ø§Ù†Ø¬Ø§Ù… Ø´Ø¯."]).slice(0, 3);
  const warnings = safeList(result?.warnings || delivery.warnings || []).slice(0, 4);

  function saveFinalProject() {
    approveProjectStep("run");
    const payload = { domain, project, summary, result, aiPreview, savedAt: new Date().toISOString() };
    localStorage.setItem("shil:finalEngineeringOutput", JSON.stringify(payload));
    markCurrentProjectFinal({ result, aiPreview });
    setRan(true);
    showUxToast("Ù¾Ø±ÙˆÚ˜Ù‡ Ø¯Ø± Ø¨Ø®Ø´ Ù¾Ø±ÙˆÚ˜Ù‡â€ŒÙ‡Ø§ÛŒ Ù†Ù‡Ø§ÛŒÛŒ Ø«Ø¨Øª Ø´Ø¯", "success");
  }

  async function exportPdf() {
    try {
      setExporting("pdf");
      await exportElementAsPdf(exportSheetRef.current, delivery, `${projectTitle || "shil"}-one-page-summary.pdf`);
      showUxToast("PDF Ø®Ù„Ø§ØµÙ‡ ÛŒÚ©â€ŒØµÙØ­Ù‡â€ŒØ§ÛŒ Ø°Ø®ÛŒØ±Ù‡ Ø´Ø¯", "success");
    } catch {
      showUxToast("Ø®Ø±ÙˆØ¬ÛŒ PDF Ø¨Ø§ Ø®Ø·Ø§ Ø±ÙˆØ¨Ù‡â€ŒØ±Ùˆ Ø´Ø¯", "warning");
    } finally {
      setExporting("");
    }
  }

  async function shareProject() {
    try {
      await shareDelivery(delivery);
      showUxToast("Ø®Ø±ÙˆØ¬ÛŒ Ù†Ù‡Ø§ÛŒÛŒ Ø¨Ø±Ø§ÛŒ Ø§Ø´ØªØ±Ø§Ú© Ø¢Ù…Ø§Ø¯Ù‡ Ø´Ø¯", "success");
    } catch {
      showUxToast("Ø§Ø´ØªØ±Ø§Ú©â€ŒÚ¯Ø°Ø§Ø±ÛŒ Ø§Ù†Ø¬Ø§Ù… Ù†Ø´Ø¯", "warning");
    }
  }

  async function saveProjectImage() {
    try {
      setExporting("png");
      await exportElementAsPng(exportSheetRef.current, `${projectTitle || "shil"}-one-page-summary.png`);
      showUxToast("ØªØµÙˆÛŒØ± Ø®Ù„Ø§ØµÙ‡ ÛŒÚ©â€ŒØµÙØ­Ù‡â€ŒØ§ÛŒ Ø°Ø®ÛŒØ±Ù‡ Ø´Ø¯", "success");
    } catch {
      showUxToast("Ø°Ø®ÛŒØ±Ù‡ ØªØµÙˆÛŒØ± Ø§Ù†Ø¬Ø§Ù… Ù†Ø´Ø¯", "warning");
    } finally {
      setExporting("");
    }
  }

  return (
    <EngineeringPageShell title="Ø§Ø¬Ø±Ø§ÛŒ Ù…Ø­Ø§Ø³Ø¨Ø§Øª Ùˆ Ø®Ø±ÙˆØ¬ÛŒ Ù†Ù‡Ø§ÛŒÛŒ">
      <section className="shil-card-stack shil-final-delivery-page shil-final-delivery-compact">
        <div className="shil-final-one-page-sheet" ref={exportSheetRef}>
          <div className="shil-final-sheet-hero">
            <div>
              <span>SHIL FINAL SUMMARY</span>
              <h2>Ø®Ù„Ø§ØµÙ‡ Ù†Ù‡Ø§ÛŒÛŒ Ù¾Ø±ÙˆÚ˜Ù‡</h2>
              <p>Ø®Ø±ÙˆØ¬ÛŒ ÙØ´Ø±Ø¯Ù‡ Ø´Ø§Ù…Ù„ Ù…Ø¹Ø±ÙÛŒ Ù¾Ø±ÙˆÚ˜Ù‡ØŒ Ù…Ø³ÛŒØ± ØªØµÙ…ÛŒÙ…â€ŒÚ¯ÛŒØ±ÛŒØŒ ØªØ¬Ù‡ÛŒØ²Ø§Øª Ùˆ Ù†ØªØ§ÛŒØ¬ Ù…Ù‡Ù…</p>
            </div>
            <strong>{delivery.meta.status}</strong>
          </div>

          <div className="shil-final-sheet-grid">
            <Row label="Ù†Ø§Ù… Ù¾Ø±ÙˆÚ˜Ù‡" value={projectTitle} />
            <Row label="Ù…Ø´ØªØ±ÛŒ / Ú©Ø§Ø±ÙØ±Ù…Ø§" value={delivery.meta.customer} />
            <Row label="Ù…Ø­Ù„ Ø§Ø¬Ø±Ø§" value={delivery.meta.location} />
            <Row label="Ù†ÙˆØ¹ Ù¾Ø±ÙˆÚ˜Ù‡" value={delivery.meta.domain} />
            <Row label="Ù…Ø³ÛŒØ± Ø·Ø±Ø§Ø­ÛŒ" value={methodSummary.title} />
            <Row label="ÙˆØ¶Ø¹ÛŒØª Ø³Ù„Ø§Ù…Øª" value={diagnostics?.score ? `${diagnostics.score} / 100` : delivery.meta.status} />
          </div>

          <DecisionPath methodSummary={methodSummary} result={result} calculationInput={calculationInput} solarDesign={solarDesign} emergency={emergency} />
          <CompactEquipmentTable title="Ø®Ù„Ø§ØµÙ‡ Ù…Ø­ØµÙˆÙ„Ø§Øª Ùˆ ØªØ¬Ù‡ÛŒØ²Ø§Øª" rows={delivery.equipment.length ? delivery.equipment : methodSummary.rows} />
          <FinalResultFields result={result} solarDesign={solarDesign} />
          <DistributedInverterTable systems={solarDesign?.distributedInverterSystems || result?.values?.distributedInverterSystems || result?.summary?.distributedInverterSystems || []} />

          <div className="shil-final-sheet-block shil-final-result-block">
            <h3>Ù†ØªØ§ÛŒØ¬ Ùˆ Ù†Ú©Ø§Øª Ù…Ù‡Ù…</h3>
            <ul>
              {importantNotes.map((item, index) => <li key={safeKey(item, index)}>{safeText(item)}</li>)}
              {warnings.map((item, index) => <li className="warning" key={safeKey(item, index)}>Ù‡Ø´Ø¯Ø§Ø±: {safeText(item)}</li>)}
              {!warnings.length ? <li>Ø·Ø±Ø§Ø­ÛŒ Ø¨Ø±Ø§ÛŒ Ø§Ø±Ø§Ø¦Ù‡ Ø®Ø±ÙˆØ¬ÛŒ Ù†Ù‡Ø§ÛŒÛŒ Ø¢Ù…Ø§Ø¯Ù‡ Ø§Ø³Øª.</li> : null}
            </ul>
          </div>
        </div>

        <div className="shil-section-card shil-final-action-card">
          <div className="shil-section-head"><h2>Ø®Ø±ÙˆØ¬ÛŒ Ù†Ù‡Ø§ÛŒÛŒ</h2><span>ÙÙ‚Ø· Ø³Ù‡ Ù‚Ø§Ø¨Ù„ÛŒØª Ø§ØµÙ„ÛŒ</span></div>
          <div className="shil-output-actions shil-output-actions-three">
            <button type="button" onClick={saveProjectImage} disabled={Boolean(exporting)}>{exporting === "png" ? "Ø¯Ø± Ø­Ø§Ù„ Ø³Ø§Ø®Øª ØªØµÙˆÛŒØ±..." : "Ø®Ø±ÙˆØ¬ÛŒ ØªØµÙˆÛŒØ±"}</button>
            <button type="button" onClick={exportPdf} disabled={Boolean(exporting)}>{exporting === "pdf" ? "Ø¯Ø± Ø­Ø§Ù„ Ø³Ø§Ø®Øª PDF..." : "Ø®Ø±ÙˆØ¬ÛŒ PDF"}</button>
            <button type="button" onClick={shareProject}>Ø§Ø´ØªØ±Ø§Ú©â€ŒÚ¯Ø°Ø§Ø±ÛŒ Ø®Ø±ÙˆØ¬ÛŒ</button>
          </div>
        </div>

        <button type="button" className="shil-primary-wide" onClick={saveFinalProject}>{ran ? "Ù¾Ø±ÙˆÚ˜Ù‡ Ø¯Ø± Ù†Ù‡Ø§ÛŒÛŒâ€ŒÙ‡Ø§ Ø«Ø¨Øª Ø´Ø¯" : "ØªØ§ÛŒÛŒØ¯ Ù†Ù‡Ø§ÛŒÛŒ Ùˆ Ø«Ø¨Øª Ù¾Ø±ÙˆÚ˜Ù‡"}</button>
        <Link className="shil-soft-link-button" to="/projects/final">Ù…Ø´Ø§Ù‡Ø¯Ù‡ Ù¾Ø±ÙˆÚ˜Ù‡â€ŒÙ‡Ø§ÛŒ Ù†Ù‡Ø§ÛŒÛŒ</Link>
      </section>
    </EngineeringPageShell>
  );
}
