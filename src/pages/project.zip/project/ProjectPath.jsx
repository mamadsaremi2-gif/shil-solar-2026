import React, { useEffect, useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { approveProjectStep } from "../../workflow/projectWorkflow.js";
import { clearScenarioFlow, startUtilityGateway, setWorkflowMode, FLOW_MODES } from "../../workflow/flowIsolation.js";
import EngineeringPageShell from "../../components/EngineeringPageShell.jsx";
import { readAdminDefaults, readAdminProjectPathCards } from "../../admin/adminStore.js";

const fallbackOptions = [
  {
    key: "solar",
    title: "Ø¨Ø±Ù‚ Ø®ÙˆØ±Ø´ÛŒØ¯ÛŒ Ø¨Ø§ Ù¾Ù†Ù„",
    description: "Ø·Ø±Ø§Ø­ÛŒ Ø®ÙˆØ±Ø´ÛŒØ¯ÛŒ Ù…Ø¹Ù…ÙˆÙ„ÛŒ Ø¨Ø§ Ù¾Ù†Ù„ØŒ Ø¨Ø§ØªØ±ÛŒØŒ Ø§ÛŒÙ†ÙˆØ±ØªØ± Ùˆ Ø®Ø±ÙˆØ¬ÛŒ Ù…Ù‡Ù†Ø¯Ø³ÛŒ ØªØ§ Ù…Ø­Ø¯ÙˆØ¯Ù‡ Ø³Ø¨Ú©/Ù…ØªÙˆØ³Ø·",
    image: "/assets/shil/execution/solar-execution.png",
    calculationDomain: "solar",
    order: 1,
  },
  {
    key: "emergency",
    title: "Ø¨Ø±Ù‚ Ø§Ø¶Ø·Ø±Ø§Ø±ÛŒ",
    description: "Ø·Ø±Ø§Ø­ÛŒ Ø³ÛŒØ³ØªÙ… Ù¾Ø´ØªÛŒØ¨Ø§Ù† Ø¨Ø§ Ø§ÛŒÙ†ÙˆØ±ØªØ±ØŒ Ø¨Ø§ØªØ±ÛŒ Ùˆ Ø²Ù…Ø§Ù† Ø¨Ø±Ù‚ Ø§Ø¶Ø·Ø±Ø§Ø±ÛŒ Ù…ÙˆØ±Ø¯ Ù†ÛŒØ§Ø²",
    image: "/assets/shil/execution/emergency-inverter-battery.png",
    calculationDomain: "emergency",
    order: 2,
  },
  {
    key: "utility",
    title: "Ù†ÛŒØ±ÙˆÚ¯Ø§Ù‡ÛŒ",
    description: "Ø¯Ø±Ú¯Ø§Ù‡ Ù…Ø³ØªÙ‚Ù„ Ø·Ø±Ø§Ø­ÛŒ Ù†ÛŒØ±ÙˆÚ¯Ø§Ù‡ Ø®ÙˆØ±Ø´ÛŒØ¯ÛŒ Ø¨Ø§Ù„Ø§ÛŒ Û³Û°kW ØªØ§ Ø¸Ø±ÙÛŒØªâ€ŒÙ‡Ø§ÛŒ MWØŒ Ø´Ø§Ù…Ù„ Ø¨Ù„ÙˆÚ©â€ŒØ¨Ù†Ø¯ÛŒØŒ MVØŒ ØªØ±Ø§Ù†Ø³ Ùˆ Grid Study Ù…Ù‚Ø¯Ù…Ø§ØªÛŒ",
    image: "/assets/shil/execution/utility-execution.png",
    calculationDomain: "utility",
    order: 3,
  },
];

function normalizeCards(cards) {
  if (!Array.isArray(cards)) return fallbackOptions;
  const safeCards = cards
    .filter((item) => item && item.key && item.title && item.active !== false)
    .filter((item) => !["future", "development", "under-development", "coming-soon"].includes(String(item.key || "").toLowerCase()))
    .filter((item) => !/Ø¯Ø± Ø­Ø§Ù„ ØªÙˆØ³Ø¹Ù‡|ØªÙˆØ³Ø¹Ù‡/.test(String(item.title || "")))
    .map((item) => ({
      key: String(item.key),
      title: String(item.title),
      description: String(item.description || ""),
      image: String(item.image || ""),
      calculationDomain: String(item.calculationDomain || item.key),
      order: Number(item.order || 99),
    }));

  const base = safeCards.length ? safeCards : fallbackOptions;
  const withoutDev = base.filter((item) => !["future", "development", "under-development", "coming-soon"].includes(String(item.key || "").toLowerCase()) && !/Ø¯Ø± Ø­Ø§Ù„ ØªÙˆØ³Ø¹Ù‡|ØªÙˆØ³Ø¹Ù‡/.test(String(item.title || "")));
  const hasUtility = withoutDev.some((item) => item.calculationDomain === "utility" || item.key === "utility");
  const withUtility = hasUtility ? withoutDev : [...withoutDev, fallbackOptions.find((item) => item.key === "utility")].filter(Boolean);
  return withUtility.sort((a, b) => (Number(a.order || 99) - Number(b.order || 99)));
}

export default function ProjectPath() {
  const navigate = useNavigate();
  const [selected, setSelected] = useState("");
  const [warning, setWarning] = useState("");
  const [options, setOptions] = useState(() => normalizeCards(readAdminProjectPathCards()));

  useEffect(() => {
    let alive = true;
    const adminCards = normalizeCards(readAdminProjectPathCards());
    if (adminCards.length) {
      setOptions(adminCards);
      return () => { alive = false; };
    }

    fetch(`/project-path-cards.json?v=${Date.now()}`, { cache: "no-store" })
      .then((res) => (res.ok ? res.json() : fallbackOptions))
      .then((cards) => {
        if (alive) setOptions(normalizeCards(cards));
      })
      .catch(() => {
        if (alive) setOptions(fallbackOptions);
      });

    return () => { alive = false; };
  }, []);

  const mainOptions = useMemo(
    () => options.filter((item) => !(item.calculationDomain === "utility" || item.key === "utility")),
    [options]
  );

  const utilityOption = useMemo(
    () => options.find((item) => item.calculationDomain === "utility" || item.key === "utility"),
    [options]
  );

  const selectedOption = useMemo(
    () => options.find((item) => item.key === selected),
    [options, selected]
  );

  const confirm = () => {
    if (!selectedOption) {
      setWarning("Ù„Ø·ÙØ§Ù‹ ÛŒÚ©ÛŒ Ø§Ø² Ù…Ø³ÛŒØ±Ù‡Ø§ÛŒ Ù¾Ø±ÙˆÚ˜Ù‡ Ø±Ø§ Ø§Ù†ØªØ®Ø§Ø¨ Ú©Ù†ÛŒØ¯.");
      return;
    }

    const domain = selectedOption.calculationDomain || selectedOption.key;

    clearScenarioFlow();
    setWorkflowMode(domain === "utility" ? FLOW_MODES.UTILITY : FLOW_MODES.MANUAL);
    approveProjectStep("path");
    localStorage.setItem("shil:projectPath", selectedOption.key);
    localStorage.setItem("shil:selectedProjectPath", JSON.stringify(selectedOption));
    localStorage.setItem("shil:executionMethod", selectedOption.key);
    localStorage.setItem("shil:calculationDomain", domain);
    if (domain === "utility") {
      localStorage.setItem("shil:scenarioDomain", "utility");
    } else {
      localStorage.removeItem("shil:scenarioDomain");
    }

    if (domain === "future") {
      navigate("/new-project/future");
      return;
    }

    if (domain === "utility") {
      approveProjectStep("method");
      approveProjectStep("inputs");
      localStorage.setItem("shil:selectedCalculationMethod", JSON.stringify({ key: "utility_scale", title: "Ù†ÛŒØ±ÙˆÚ¯Ø§Ù‡ÛŒ" }));
      localStorage.setItem("shil:calculationMethod", "utility_scale");
      startUtilityGateway("project-path");
      navigate("/new-project/system/utility?from=project-path&gateway=utility");
      return;
    }

    if (domain === "emergency") {
      localStorage.setItem("shil:selectedCalculationMethod", JSON.stringify({ key: "emergency", title: "Ø¨Ø±Ù‚ Ø§Ø¶Ø·Ø±Ø§Ø±ÛŒ" }));
      localStorage.setItem("shil:calculationMethod", "equipment");
      const adminDefaults = readAdminDefaults();
      localStorage.setItem("shil:emergencyPowerSettings", JSON.stringify({ requiredEmergencyHours: adminDefaults.emergencyRequiredHours || 2, safetyFactor: adminDefaults.emergencySafetyFactor || 1.25, autoMode: true }));
      navigate("/new-project/info");
      return;
    }

    navigate("/new-project/info");
  };

  return (
    <EngineeringPageShell title="Ø§Ù†ØªØ®Ø§Ø¨ Ù…Ø³ÛŒØ± Ù¾Ø±ÙˆÚ˜Ù‡">
      <section className="shil-card-stack">
        <div className="shil-section-card">
          <div className="shil-section-head">
            <h2>Ù…Ø³ÛŒØ± Ù¾Ø±ÙˆÚ˜Ù‡ Ø±Ø§ Ø§Ù†ØªØ®Ø§Ø¨ Ú©Ù†ÛŒØ¯</h2>
            <span>Project Path</span>
          </div>

          <div className="shil-execution-grid shil-project-path-two-cards">
            {mainOptions.map((option) => (
              <button
                type="button"
                key={option.key}
                className={`shil-execution-card shil-project-path-card ${selected === option.key ? "active" : ""}`}
                onClick={() => { setSelected(option.key); setWarning(""); }}
              >
                {option.image ? <img src={option.image} alt="" className="shil-execution-image" /> : null}
                <span className="shil-execution-check">{selected === option.key ? "âœ“" : ""}</span>
                <h3>{option.title}</h3>
                <p>{option.description}</p>
              </button>
            ))}
          </div>

          {utilityOption ? (
            <details className={`shil-utility-path-field ${selected === utilityOption.key ? "active" : ""}`}>
              <summary>
                <span>Ù…Ø³ÛŒØ± Ù†ÛŒØ±ÙˆÚ¯Ø§Ù‡ÛŒ</span>
                <small>Ø¨Ø±Ø§ÛŒ Ù¾Ø±ÙˆÚ˜Ù‡â€ŒÙ‡Ø§ÛŒ Ø¸Ø±ÙÛŒØª Ø¨Ø§Ù„Ø§ Ø¨Ø§Ø² Ú©Ù†ÛŒØ¯</small>
              </summary>
              <button
                type="button"
                className={`shil-utility-select-button ${selected === utilityOption.key ? "active" : ""}`}
                onClick={() => { setSelected(utilityOption.key); setWarning(""); }}
              >
                {utilityOption.image ? <img src={utilityOption.image} alt="" /> : null}
                <span>
                  <strong>{utilityOption.title}</strong>
                  <small>{utilityOption.description}</small>
                </span>
                <b>{selected === utilityOption.key ? "âœ“" : "Ø§Ù†ØªØ®Ø§Ø¨"}</b>
              </button>
            </details>
          ) : null}

          {warning ? <div className="shil-inline-warning">{warning}</div> : null}
          <button type="button" className="shil-primary-wide" onClick={confirm}>ØªØ£ÛŒÛŒØ¯ Ù…Ø³ÛŒØ± Ù¾Ø±ÙˆÚ˜Ù‡</button>
        </div>
      </section>
    </EngineeringPageShell>
  );
}
